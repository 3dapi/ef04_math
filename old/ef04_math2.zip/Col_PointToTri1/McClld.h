// Interface for the CMcBresenham class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCCLLID_H_
#define _MCCLLID_H_

class CMcClld
{
protected:
	VtxD		m_pTri[3];
	D3DXVECTOR3		m_Pos;

	BOOL		m_bColl;
	LPD3DXMESH	m_pMsh;


public:
	CMcClld();
	~CMcClld();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif