// Interface for the CMcBresenham class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCCLLID_H_
#define _MCCLLID_H_

class CMcClld
{
protected:
	VtxD		m_pTri1[3];
	VtxD		m_pTri2[3];

	BOOL		m_bColl;

	D3DXVECTOR3 m_vcPick[2];
	LPD3DXMESH	m_pMsh;

	
public:
	CMcClld();
	~CMcClld();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif