// McLyr.cpp: implementation of the CMcLyr class.
//
//////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcLyr::CMcLyr()
{

}

CMcLyr::~CMcLyr()
{
	Destroy();
}


INT CMcLyr::Init()
{
	FLOAT	fMax;

	fMax = 50000;

	m_pXYZ[ 0] = VtxD(-fMax,     0,     0, 0xFFFF0000);
	m_pXYZ[ 1] = VtxD(    0,     0,     0, 0xFFFF0000);
	m_pXYZ[ 2] = VtxD(    0,     0,     0, 0xFFFF0000);
	m_pXYZ[ 3] = VtxD( fMax,     0,     0, 0xFFFF0000);
	
	m_pXYZ[ 4] = VtxD(    0, -fMax,     0, 0xFF00FF00);
	m_pXYZ[ 5] = VtxD(    0,     0,     0, 0xFF00FF00);
	m_pXYZ[ 6] = VtxD(    0,     0,     0, 0xFF00FF00);
	m_pXYZ[ 7] = VtxD(    0,  fMax,     0, 0xFF00FF00);
	
	m_pXYZ[ 8] = VtxD(    0,     0, -fMax, 0xFF0000FF);
	m_pXYZ[ 9] = VtxD(    0,     0,     0, 0xFF0000FF);
	m_pXYZ[10] = VtxD(    0,     0,     0, 0xFF0000FF);
	m_pXYZ[11] = VtxD(    0,     0,  fMax, 0xFF0000FF);

	return 1;
}



void CMcLyr::Destroy()
{
}


void CMcLyr::Render()
{
	GDEVICE->SetRenderState( D3DRS_LIGHTING,  FALSE);
	GDEVICE->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	GDEVICE->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);
	
	GDEVICE->SetTexture(0, 0);
	GDEVICE->SetFVF(VtxD::FVF);
	GDEVICE->DrawPrimitiveUP(D3DPT_LINELIST, 6, m_pXYZ, sizeof(VtxD));
}