// Interface for the CMcLyr class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCLYR_H_
#define _MCLYR_H_


class CMcLyr  
{
protected:
	VtxD	m_pXYZ[12]	;
	
public:
	CMcLyr();
	virtual ~CMcLyr();

	INT		Init();
	void	Destroy();


	void	Render();
};

#endif