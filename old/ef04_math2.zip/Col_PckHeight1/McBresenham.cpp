// Implementation of the CMcBresenham class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcBresenham::CMcBresenham()
:	m_pTile		(0)
{
}

CMcBresenham::~CMcBresenham()
{
	Destroy();
}


INT CMcBresenham::Init()
{
	INT		i;
	INT		j;
	FLOAT	fMax;

	fMax = 10000;
	m_fW = 16;

	m_pTile = (VtxD*)malloc( (6 + 17*2 ) * 2 * sizeof(VtxD));
	memset(m_pTile, 0, (6 + 17*2 ) * 2 * sizeof(VtxD));

	m_pTile[ 0] = VtxD(-fMax,     0,     0, 0xFFFF0000);
	m_pTile[ 1] = VtxD(    0,     0,     0, 0xFFFF0000);
	m_pTile[ 2] = VtxD(    0,     0,     0, 0xFFFF0000);
	m_pTile[ 3] = VtxD( fMax,     0,     0, 0xFFFF0000);
	
	m_pTile[ 4] = VtxD(    0, -fMax,     0, 0xFF00FF00);
	m_pTile[ 5] = VtxD(    0,     0,     0, 0xFF00FF00);
	m_pTile[ 6] = VtxD(    0,     0,     0, 0xFF00FF00);
	m_pTile[ 7] = VtxD(    0,  fMax,     0, 0xFF00FF00);
	
	m_pTile[ 8] = VtxD(    0,     0, -fMax, 0xFF0000FF);
	m_pTile[ 9] = VtxD(    0,     0,     0, 0xFF0000FF);
	m_pTile[10] = VtxD(    0,     0,     0, 0xFF0000FF);
	m_pTile[11] = VtxD(    0,     0,  fMax, 0xFF0000FF);

	j =6 * 2;

	for(i=0; i<17; ++i)
	{
		m_pTile[j + 2*i +0 ] = VtxD( m_fW* i, 0,   0, 0xFF999999);
		m_pTile[j + 2*i +1 ] = VtxD( m_fW* i, 0, 256, 0xFF999999);

		m_pTile[j + 17* 2 + 2*i +0 ] = VtxD(   0, 0,  m_fW* i, 0xFF999999);
		m_pTile[j + 17* 2 + 2*i +1 ] = VtxD( 256, 0,  m_fW* i, 0xFF999999);
	}


	m_pLine[0].p = VEC3(  600, 0, -20);
	m_pLine[1].p = VEC3(  -10, 0,  20);

	m_pLine[0].p = VEC3(  -10, 0, -10);
	m_pLine[1].p = VEC3(  300, 0, 280);

	return 1;
}


void CMcBresenham::Destroy()
{
	SAFE_FREE(		m_pTile		);
}


INT	CMcBresenham::FrameMove()
{

	if(GINPUT->KeyState(DIK_LEFT))
	{
		m_pLine[0].p.x -= 2;
	}

	if(GINPUT->KeyState(DIK_RIGHT))
	{
		m_pLine[0].p.x += 2;
	}

	if(GINPUT->KeyState(DIK_DOWN))
	{
		m_pLine[0].p.z -= 2;
	}

	if(GINPUT->KeyState(DIK_UP))
	{
		m_pLine[0].p.z += 2;
	}


	if(GINPUT->KeyState(DIK_DELETE))
	{
		m_pLine[1].p.x -= 2;
	}

	if(GINPUT->KeyState(DIK_NEXT))
	{
		m_pLine[1].p.x += 2;
	}

	if(GINPUT->KeyState(DIK_END))
	{
		m_pLine[1].p.z -= 2;
	}

	if(GINPUT->KeyState(DIK_HOME))
	{
		m_pLine[1].p.z += 2;
	}



	
	m_vRc.clear();

	VEC3	vcD = m_pLine[1].p- m_pLine[0].p;

	FLOAT	fA;
	FLOAT	fB;
	
	if(0.f == vcD.x)
		fA = FLT_MAX;
	
	else
		fA= vcD.z/vcD.x;

	fA = fA;
	fB = m_pLine[0].p.z - fA * m_pLine[0].p.x;

	for(int i=0; i<16; ++i)
	{
		FLOAT	x;
		FLOAT	z;

		
		McRect	rc;

		x = i* m_fW;
		z = fA* i + fB/m_fW;
		z = floorf(z);
		
		if( z>=0 && z<16)
		{
			z *= m_fW;
			rc.pVtx[0].p.x = x;
			rc.pVtx[0].p.z = z;

			rc.pVtx[1].p.x = x + 0;
			rc.pVtx[1].p.z = z + m_fW;

			rc.pVtx[2].p.x = x + m_fW;
			rc.pVtx[2].p.z = z + 0;

			rc.pVtx[3].p.x = x + m_fW;
			rc.pVtx[3].p.z = z + m_fW;

			m_vRc.push_back(rc);
		}



		z = i * m_fW;
		x = (m_fW * i - fB)/(fA*m_fW);
		x = floorf(x);

		if( x>=0 && x<16)
		{
			if(fA>=0)
			{
				x *= m_fW;
				rc.pVtx[0].p.x = x;
				rc.pVtx[0].p.z = z;

				rc.pVtx[1].p.x = x + 0;
				rc.pVtx[1].p.z = z + m_fW;

				rc.pVtx[2].p.x = x + m_fW;
				rc.pVtx[2].p.z = z + 0;

				rc.pVtx[3].p.x = x + m_fW;
				rc.pVtx[3].p.z = z + m_fW;

				m_vRc.push_back(rc);
			}

			else if(z>0)
			{
				z = (i-1) * m_fW;
				x *= m_fW;
				rc.pVtx[0].p.x = x;
				rc.pVtx[0].p.z = z;

				rc.pVtx[1].p.x = x + 0;
				rc.pVtx[1].p.z = z + m_fW;

				rc.pVtx[2].p.x = x + m_fW;
				rc.pVtx[2].p.z = z + 0;

				rc.pVtx[3].p.x = x + m_fW;
				rc.pVtx[3].p.z = z + m_fW;

				m_vRc.push_back(rc);
			}
		}
	}
	
	return 1;
}

void CMcBresenham::Render()
{
	// Render Lines
	GDEVICE->SetRenderState( D3DRS_LIGHTING,  FALSE);
	GDEVICE->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	GDEVICE->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);
	GDEVICE->SetRenderState( D3DRS_ZENABLE, FALSE);
	
	GDEVICE->SetTexture(0, 0);
	GDEVICE->SetFVF(VtxD::FVF);

	GDEVICE->DrawPrimitiveUP(D3DPT_LINELIST, 6 + 17*2, m_pTile, sizeof(VtxD));

	GDEVICE->DrawPrimitiveUP(D3DPT_LINELIST, 1, m_pLine, sizeof(VtxD));


	GDEVICE->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME);

	int iSize = m_vRc.size();

	for(int i=0; i<iSize; ++i)
	{
		GDEVICE->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, m_vRc[i].pVtx, sizeof(VtxD));
	}

	GDEVICE->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID);

	GDEVICE->SetRenderState( D3DRS_ZENABLE, TRUE);
}