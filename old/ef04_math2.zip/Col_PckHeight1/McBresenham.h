// Interface for the CMcBresenham class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCBRESENHAM_H_
#define _MCBRESENHAM_H_


struct McRect
{
	VtxD	pVtx[4];

	McRect()
	{
		pVtx[0].d = 0x44FFFF00;
		pVtx[1].d = 0x44FFFF00;
		pVtx[2].d = 0x44FFFF00;
		pVtx[3].d = 0x44FFFF00;

		pVtx[0].p.y = 0.f;
		pVtx[1].p.y = 0.f;
		pVtx[2].p.y = 0.f;
		pVtx[3].p.y = 0.f;
	}
};

typedef vector<McRect>		lsMcRect;
typedef lsMcRect::iterator	itMcRect;


class CMcBresenham
{
protected:
	VtxD*		m_pTile;
	VtxD		m_pLine[2];

	FLOAT		m_fW;


	lsMcRect	m_vRc;
	
public:
	CMcBresenham();
	~CMcBresenham();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif