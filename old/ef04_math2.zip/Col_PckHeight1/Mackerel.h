// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


class CMain : public CD3DApplication
{
public:
	ID3DXFont*			m_pD3DXFont	;											// D3DX font
	CMcInput*			m_pInput	;
	CMcCam*				m_pCam		;
	
	CMcBresenham*		m_pBresen	;
	
	BOOL				m_bSolid	;
	INT					m_nCull		;
	BOOL				m_bTx		;

public:
	CMain();
	LRESULT MsgProc( HWND, UINT, WPARAM, LPARAM);
	virtual HRESULT Init();
	virtual HRESULT Destroy();

	virtual HRESULT Restore();
	virtual HRESULT Invalidate();
	
	virtual HRESULT FrameMove();
	virtual HRESULT Render();
	
	HRESULT RenderText();
};