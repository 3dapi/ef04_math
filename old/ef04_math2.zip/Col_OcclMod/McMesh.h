#ifndef _MCMESH_H_
#define _MCMESH_H_


class CMcMesh
{
public:
	PDEV			m_pDev;
	CHAR			m_sFile[256];
	CHAR			m_sPath[256];

	INT				m_iMtl;			// Number of materials
	INT				m_iFce;			// Number of faces
	INT				m_iVtx;			// Number of vertices

	DMTL*			m_msMtl;		// Materials for mesh
	PDTX*			m_msTx;			// Textures for mesh
	LPD3DXMESH		m_msObj;		// D3DX Mesh object

public:
	CMcMesh();
	virtual ~CMcMesh();

	INT		Create(PDEV pDev, CHAR* sFile);
	void	Destroy();

	void	Render(D3DXMATRIX matPos );

	INT		GetNumFaces();
	INT		GetNumVerts();
};


#endif
