// Interface for the COcclCull class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MD2MDL_H_
#define _MD2MDL_H_


struct McObj
{
	CMcMesh*	pMesh;			// Reference to a mesh object
	CMcMesh*	pBound;			// Reference to low-poly bounding mesh

	DWORD		nId;
	D3DXVECTOR3		vcP;			// Translation matrix for this object
	D3DXMATRIX		mtWld;

	BOOL		bRnd;			// If true, render the object

	LPD3DXMESH	pmsBox;			// D3DX Mesh Box object

	McObj( CMcMesh* meshRef, CMcMesh* boundMesh,DWORD _nId, D3DXVECTOR3 _vcP )
	{
		pMesh	= meshRef;
		pBound  = boundMesh;
		nId		= _nId;
		vcP		= _vcP;
		bRnd	= 0;
		pmsBox	= NULL;

		if(pBound)
		{
			pBound->m_msObj->CloneMeshFVF(D3DXMESH_MANAGED, VtxD::FVF, pBound->m_pDev, &pmsBox);

			VtxD *pVtx;
			pmsBox->LockVertexBuffer(0, (void**)&pVtx);

			for(int k=0; k<pBound->m_iVtx; ++k)
				pVtx[k].d = nId;

			pmsBox->UnlockVertexBuffer();

		}

	}


	~McObj()
	{
		SAFE_RELEASE(	pmsBox	);
	}


	INT FrameMove()
	{
		D3DXMatrixTranslation( &mtWld, vcP.x, vcP.y, vcP.z );
		return 1;
	}

	void Render()
	{
		pMesh->Render(mtWld );
	}

	void RenderBoundingBox()
	{
		pBound->m_pDev->SetTransform( D3DTS_WORLD, &mtWld );

		for( DWORD i = 0; i < pBound->m_iMtl; ++i )
		{
			pmsBox->DrawSubset( i );
		}
	}

	INT GetNumVerts()
	{
		return pMesh->GetNumVerts();
	}
};


typedef std::vector<McObj*>	lsObj;


class COcclCull
{
protected:
	INT			m_iOccImgX		;			// Occlusion Image Width
	INT			m_iOccImgY		;			// Occlusion Image Height

	INT			m_iVtx			;			// Number of m_iVtx rendered this frame
	INT			m_iRen			;			// Number of trees rendered this frame

	lsObj		m_lsObj			;			// Vector of m_lsObj
	CMcMesh*	m_msTerrain		;			// The terrain mesh
	CMcMesh*	m_msTree		;			// The tree mesh
	CMcMesh*	m_msTreeBox		;			// Bounding mesh for tree

	PDRS		m_pOccRSF		;			// Occlusion's render to surface
	PDSF		m_pOccOs		;			// Occlusion's surface that it uses
	PDTX		m_pOccOt		;			// Texture to get surface from

	BOOL		m_bCull			;
	DWORD*		m_pId			;			// Id�� ��Ƴ��� ����


public:
	COcclCull();
	virtual ~COcclCull();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();

	INT		Restore();
	void	Invalidate();

protected:
	INT		OcclusionCull();
	FLOAT	GetRandom();
};


#endif