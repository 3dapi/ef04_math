// Implementation of the COcclCull class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


COcclCull::COcclCull()
{
	m_msTerrain	= NULL;
	m_msTree	= NULL;
	m_msTreeBox	= NULL;

	m_pOccRSF	= NULL;
	m_pOccOs	= NULL;
	m_pOccOt	= NULL;


	m_iOccImgX	= 160;
	m_iOccImgY	= 120;

	m_iVtx		= 0;
	m_iRen		= 0;

	m_bCull		= 1;
}


COcclCull::~COcclCull()
{
	Destroy();
}



INT COcclCull::Init()
{
	// Load the meshes
	m_msTerrain = new CMcMesh;
	if( FAILED( m_msTerrain->Create( GDEVICE, "Model/terrain.x" ) ) )
		return -1;

	m_msTree = new CMcMesh;
	if( FAILED( m_msTree->Create( GDEVICE, "Model/tree.x" ) ) )
		return -1;

	m_msTreeBox = new CMcMesh;
	if( FAILED( m_msTreeBox->Create( GDEVICE, "Model/tree_bounding.x") ) )
		return -1;


	for(int i=0; i<600; ++i)
	{
		D3DXVECTOR3 pos = D3DXVECTOR3( GetRandom() * 150.0f, 12.0f, GetRandom() * 150.0f );
		m_lsObj.push_back( new McObj( m_msTree, m_msTreeBox, 0xFF000000 | (i+1), pos ) );
	};


	m_pId = new DWORD[m_iOccImgX * m_iOccImgY];

	return 1;
}

void COcclCull::Destroy()
{
	SAFE_DELETE( m_msTerrain );
	SAFE_DELETE( m_msTree );
	SAFE_DELETE( m_msTreeBox );

	SAFE_DELETE_ARRAY(	m_pId );


	for(int i=0; i<600; ++i)
	{
		delete m_lsObj[i];
	};
}


int COcclCull::Restore()
{
	D3DDISPLAYMODE mode;
	GDEVICE->GetDisplayMode( 0, &mode );

	// ������Ʈ�� �ڽ��� �׸� �̹����� �����.
	if( FAILED( D3DXCreateTexture( GDEVICE, m_iOccImgX, m_iOccImgY, 1, 0, mode.Format, D3DPOOL_MANAGED, &m_pOccOt)))
		return -1;

	// ������ ������� ����� ���ǽ��� �����´�.
	m_pOccOt->GetSurfaceLevel(0, &m_pOccOs);


	D3DSURFACE_DESC desc;
	m_pOccOs->GetDesc(&desc);

	// ������ ������� ����� �̹����� ���ǽ��� ������ ũ�⸦ ���� ������
	// ŸŶ�� �����.
	if( FAILED( D3DXCreateRenderToSurface( GDEVICE, desc.Width, desc.Height, desc.Format, TRUE, D3DFMT_D16, &m_pOccRSF)))
		return -1;


	return 1;
}


void COcclCull::Invalidate()
{
	SAFE_RELEASE( m_pOccRSF );

	SAFE_RELEASE( m_pOccOs );
	SAFE_RELEASE( m_pOccOt );
}


int COcclCull::FrameMove()
{
	if(pInput->GetKey(VK_F1))
	{
		m_bCull ^=1;
	}


	for(int i=0; i<m_lsObj.size(); ++i)
	{
		m_lsObj[i]->FrameMove();
	}


	// Cull the m_lsObj
	if(m_bCull)
		OcclusionCull();

	if(pInput->GetKey(VK_M))
		D3DXSaveSurfaceToFile( "buffer.bmp", D3DXIFF_BMP, m_pOccOs, NULL, NULL );

	return 1;
}


void COcclCull::Render()
{
	m_iVtx	= 0;
	m_iRen	= 0;

	// Render the skybox first
	// Set sampler state to clamp
	GDEVICE->SetRenderState( D3DRS_DITHERENABLE,   FALSE );
	GDEVICE->SetRenderState( D3DRS_SPECULARENABLE, FALSE );
	GDEVICE->SetRenderState( D3DRS_ZENABLE, D3DZB_TRUE  );

	GDEVICE->SetRenderState( D3DRS_LIGHTING, FALSE );

	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_SRCBLENDALPHA, D3DBLEND_SRCCOLOR);
	GDEVICE->SetRenderState(D3DRS_DESTBLENDALPHA, D3DBLEND_DESTCOLOR);


	GDEVICE->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );



	GDEVICE->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	GDEVICE->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
	GDEVICE->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
	GDEVICE->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );

	// Turn clamping off, back to wrap
	GDEVICE->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
	GDEVICE->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );

	// Render the terrain plane
	D3DXMATRIX	mtWld;

	D3DXMatrixIdentity(&mtWld);

	m_msTerrain->Render(mtWld);

	for( int i = 0; i < m_lsObj.size(); ++i )
	{
		if(m_bCull)
		{
			if( m_lsObj[i]->bRnd )
			{
				m_lsObj[i]->Render();
				m_iVtx += m_lsObj[i]->GetNumVerts();
				++m_iRen;
			}
		}

		else
		{
			m_lsObj[i]->Render();
			m_iVtx += m_lsObj[i]->GetNumVerts();
			++m_iRen;
		}
	}



	CHAR	sMsg[512];
	RECT	rc={10,50, 400, 70};

	sprintf(sMsg, "Vertex:%d RenderObject:%d cull?%d", m_iVtx, m_iRen, m_bCull);

	GMAIN->m_pD3DXFont->DrawText( sMsg, -1, &rc, 0, D3DXCOLOR(1,0,1,1) );
}






float COcclCull::GetRandom()
{
	float random = (float)rand() / RAND_MAX;

	if( random < 0.5f )
		random = -random * 2;
	else
		random = (1.0f - random) * 2;

	return random;
}



INT COcclCull::OcclusionCull()
{
	if( FAILED( m_pOccRSF->BeginScene( m_pOccOs, NULL ) ) )
		return -1;

	GDEVICE->Clear(0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0X00000000, 1.0f, 0);

	// ��� ��ü�� �ٿ�� �ڽ��� �׸���.
	for( int i = 0; i < m_lsObj.size(); ++i )
		m_lsObj[i]->RenderBoundingBox();

	m_pOccRSF->EndScene( 0 );


	INT		iSize = m_iOccImgX * m_iOccImgY;

	D3DLOCKED_RECT rc;
	HRESULT hr = m_pOccOs->LockRect(&rc, NULL, NULL);
	memcpy(m_pId, rc.pBits, iSize * sizeof(DWORD));
	m_pOccOs->UnlockRect();

	sort(&m_pId[0], &m_pId[iSize]);


	// �ȼ��� �����ͼ� �������� ������ �Ǻ�!!!
	INT nStart =0;

	for(i=0; i<m_lsObj.size(); ++i)
	{
		DWORD bVisible = 0;

		for(int k=nStart; k<iSize; ++k)
		{
			if( m_lsObj[i]->nId == m_pId[k])
			{
				bVisible = 1;
				nStart	= k;
				break;
			}

		}

		m_lsObj[i]->bRnd = bVisible;

	}



	return 1;
}