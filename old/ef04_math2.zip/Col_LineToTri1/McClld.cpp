// Implementation of the CMcClld class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"

FLOAT McUtil_DotAngle(D3DXVECTOR3* p0, D3DXVECTOR3* p1, D3DXVECTOR3* p2)
{
	D3DXVECTOR3 vcA = *p1 - *p0;
	D3DXVECTOR3 vcB = *p2 - *p0;

	D3DXVec3Normalize(&vcA,&vcA);
	D3DXVec3Normalize(&vcB,&vcB);

	FLOAT fDot = D3DXVec3Dot(&vcA, &vcB);

	if(fDot>0.9999f)
		return 0.f;
	else if(fDot<-0.9999f)
		return D3DX_PI;

	fDot = acosf(fDot);

	return fDot;
}

BOOL LcMath_CollisionLineToTriangle(D3DXVECTOR3* vcOut, D3DXVECTOR3* pTri, D3DXVECTOR3* pLine)
{
	D3DXPLANE plane;
	D3DXVECTOR3 vcN;
	FLOAT		fD;

	D3DXVECTOR3 vcA = pTri[1] - pTri[0];
	D3DXVECTOR3 vcB = pTri[2] - pTri[0];

	D3DXVec3Cross(&vcN, &vcA, &vcB);
	D3DXVec3Normalize(&vcN,&vcN);

	fD = -D3DXVec3Dot(&vcN, &pTri[0]);

	plane = D3DXPLANE(vcN.x, vcN.y, vcN.z, fD);

	FLOAT fD1 = D3DXPlaneDotCoord(&plane, &pLine[0]);
	FLOAT fD2 = D3DXPlaneDotCoord(&plane, &pLine[1]);

	if(fD1 * fD2>0)																// Not Collision
		return FALSE;



	D3DXVECTOR3 vcL;
	D3DXVECTOR3 vcP;
	FLOAT		fT;
	FLOAT		fA;
	FLOAT		fB;
	FLOAT		fC;

	vcL = pLine[1]-pLine[0];
	D3DXVec3Normalize(&vcL, &vcL);

	fT = D3DXVec3Dot(&vcL, &vcN);

	if( 0.f == fT)																//���� ������ ���
	{
		fA = McUtil_DotAngle(&pLine[0], &pTri[0], &pTri[1]);
		fB = McUtil_DotAngle(&pLine[0], &pTri[1], &pTri[2]);
		fC = McUtil_DotAngle(&pLine[0], &pTri[2], &pTri[0]);

		if(fA+fB+fC>=(D3DX_PI*2-0.001f))
			return TRUE;

		fA = McUtil_DotAngle(&pLine[1], &pTri[0], &pTri[1]);
		fB = McUtil_DotAngle(&pLine[1], &pTri[1], &pTri[2]);
		fC = McUtil_DotAngle(&pLine[1], &pTri[2], &pTri[0]);

		if(fA+fB+fC>=(D3DX_PI*2-0.001f))
			return TRUE;
	}

	fT = -( fD+ D3DXVec3Dot(&vcN, &pLine[0]))/fT;

	vcP = pLine[0] + fT * vcL;

	fA = McUtil_DotAngle(&vcP, &pTri[0], &pTri[1]);
	fB = McUtil_DotAngle(&vcP, &pTri[1], &pTri[2]);
	fC = McUtil_DotAngle(&vcP, &pTri[2], &pTri[0]);

	*vcOut = vcP;

	if(fA+fB+fC>=(D3DX_PI*2-0.001f))
		return TRUE;

	return FALSE;
}

CMcClld::CMcClld()
{
	m_bColl = FALSE;

	m_pMsh	= NULL;
}

CMcClld::~CMcClld()
{
	Destroy();
}


INT CMcClld::Init()
{
	m_pTri[0]	= VtxD( 10, -100,  200, 0xFFFF7777);
	m_pTri[1]	= VtxD(500,  200,  300, 0xFF77FF77);
	m_pTri[2]	= VtxD(400,  50,    20, 0xFF7777FF);

	m_pLine[0].p = D3DXVECTOR3(  100, 300,  300);
	m_pLine[1].p = D3DXVECTOR3(  200, 100,  200);

	D3DXCreateSphere(m_pDev, 3, 8, 8, &m_pMsh, 0);

	return 1;
}


void CMcClld::Destroy()
{
	SAFE_RELEASE(m_pMsh);
}


INT	CMcClld::FrameMove()
{
	if(pInput->KeyState(VK_UP))
	{
		m_pLine[0].p.z += 1;
		m_pLine[1].p.z += 1;
	}

	if(pInput->KeyState(VK_DOWN))
	{
		m_pLine[0].p.z -= 1;
		m_pLine[1].p.z -= 1;
	}

	if(pInput->KeyState(VK_HOME))
	{
		m_pLine[0].p.y += 1;
		m_pLine[1].p.y += 1;
	}

	if(pInput->KeyState(VK_END))
	{
		m_pLine[0].p.y -= 1;
		m_pLine[1].p.y -= 1;
	}

	if(pInput->KeyState(VK_LEFT))
	{
		m_pLine[0].p.x -= 1;
		m_pLine[1].p.x -= 1;
	}

	if(pInput->KeyState(VK_RIGHT))
	{
		m_pLine[0].p.x += 1;
		m_pLine[1].p.x += 1;
	}

	D3DXVECTOR3 pTri[3];
	pTri[0] = m_pTri[0].p;
	pTri[1] = m_pTri[1].p;
	pTri[2] = m_pTri[2].p;

	D3DXVECTOR3 pLine[2];

	pLine[0] = m_pLine[0].p;
	pLine[1] = m_pLine[1].p;

	m_bColl = LcMath_CollisionLineToTriangle(&m_vcPick, pTri, pLine);

	return 1;
}

void CMcClld::Render()
{
	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pDev->SetRenderState( D3DRS_LIGHTING,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);

	m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE);

	if(m_bColl)
		m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);

	m_pDev->SetTexture(0, 0);
	m_pDev->SetFVF(VtxD::FVF);

	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 1, m_pTri, sizeof(VtxD));


	m_pDev->DrawPrimitiveUP(D3DPT_LINELIST, 1, m_pLine, sizeof(VtxD));

	if(m_bColl)
	{
		D3DLIGHT9 Lgt;
		D3DMATERIAL9	mtl;
		D3DUtil_InitLight( Lgt, D3DLIGHT_DIRECTIONAL, -1.0f, -1.0f, 2.0f );
		D3DUtil_InitMaterial(mtl,1.0f, 0.0f,0.0f);

		m_pDev->SetLight( 0, &Lgt );
		m_pDev->LightEnable( 0, TRUE );
		m_pDev->SetRenderState(D3DRS_LIGHTING, TRUE);
		m_pDev->SetRenderState( D3DRS_AMBIENT, 0x000F0F0F );

		m_pDev->SetMaterial( &mtl );

		m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
		D3DXMATRIX mtW;
		D3DXMatrixIdentity(&mtW);

		mtW._41 = m_vcPick.x;
		mtW._42 = m_vcPick.y;
		mtW._43 = m_vcPick.z;

		m_pDev->SetTransform(D3DTS_WORLD,&mtW);
		m_pMsh->DrawSubset(0);

		D3DXMatrixIdentity(&mtW);
		m_pDev->SetTransform(D3DTS_WORLD,&mtW);

		m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	}
}