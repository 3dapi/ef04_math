// Implementation of the CMcClld class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"





FLOAT LcMath_TriangleBoundSphere(D3DXVECTOR3* vcOut, D3DXVECTOR3* pTri)
{
	D3DXVECTOR3	vcT;

	D3DXVECTOR3	p1;
	D3DXVECTOR3	p2;
	D3DXVECTOR3	p3;

	FLOAT		fR=0.f;
	FLOAT		fT1=0.f;
	FLOAT		fT2=0.f;
	FLOAT		fT3=0.f;

	vcT = pTri[0];
	vcT += pTri[1];
	vcT += pTri[2];

	// �������� �ٿ�� ���� ���ͷ�..
	vcT /= 3.f;

	p1 = vcT-pTri[0];
	p2 = vcT-pTri[1];
	p3 = vcT-pTri[2];

	fT1 = D3DXVec3Length(&p1);
	fT2 = D3DXVec3Length(&p2);
	fT3 = D3DXVec3Length(&p3);

	if(fT1>fR)
		fR= fT1;

	if(fT2>fR)
		fR= fT2;

	if(fT3>fR)
		fR= fT3;

	*vcOut = vcT;

	return fR;
}

CMcClld::CMcClld()
{
	m_pMshC	= NULL;
	m_pMshR	= NULL;
}

CMcClld::~CMcClld()
{
	Destroy();
}


INT CMcClld::Init()
{
	m_pTri[0]	= VtxD(  0,  120,    0, 0xFFFF7777);
	m_pTri[1]	= VtxD(500, -120,    0, 0xFF77FF77);
	m_pTri[2]	= VtxD(200,    0,  500, 0xFF7777FF);

	D3DXCreateSphere(m_pDev, 10, 32, 32, &m_pMshC, 0);

	return 1;
}


void CMcClld::Destroy()
{
	SAFE_RELEASE(m_pMshC);
	SAFE_RELEASE(m_pMshR);
}


INT	CMcClld::FrameMove()
{
	if(pInput->KeyState(VK_UP))
	{
		m_pTri[0].p.z += 1;
		m_pTri[1].p.z += 1;
	}

	if(pInput->KeyState(VK_DOWN))
	{
		m_pTri[0].p.z -= 1;
		m_pTri[1].p.z -= 1;
	}

	if(pInput->KeyState(VK_HOME))
	{
		m_pTri[0].p.y += 1;
		m_pTri[1].p.y += 1;
	}

	if(pInput->KeyState(VK_END))
	{
		m_pTri[0].p.y -= 1;
		m_pTri[1].p.y -= 1;
	}

	if(pInput->KeyState(VK_LEFT))
	{
		m_pTri[0].p.x -= 1;
		m_pTri[1].p.x -= 1;
	}

	if(pInput->KeyState(VK_RIGHT))
	{
		m_pTri[0].p.x += 1;
		m_pTri[1].p.x += 1;
	}


	D3DXVECTOR3 pTri[3];
	pTri[0] = m_pTri[0].p;
	pTri[1] = m_pTri[1].p;
	pTri[2] = m_pTri[2].p;


	m_fR = LcMath_TriangleBoundSphere(&m_vcBndC, pTri);
	m_fR1 = D3DXVec3Length( &(m_vcBndC- pTri[0]));
	m_fR2 = D3DXVec3Length( &(m_vcBndC- pTri[1]));
	m_fR3 = D3DXVec3Length( &(m_vcBndC- pTri[2]));

	SAFE_RELEASE(m_pMshR)
	D3DXCreateSphere(m_pDev, m_fR, 64, 64, &m_pMshR, 0);

	return 1;
}

void CMcClld::Render()
{
	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pDev->SetRenderState( D3DRS_LIGHTING,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);

	m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE);

	m_pDev->SetTexture(0, 0);
	m_pDev->SetFVF(VtxD::FVF);

	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 1, m_pTri, sizeof(VtxD));


	D3DLIGHT9 Lgt;
	D3DMATERIAL9	mtl;
	D3DUtil_InitLight( Lgt, D3DLIGHT_DIRECTIONAL, -1.0f, -1.0f, 2.0f );
	D3DUtil_InitMaterial(mtl,1.0f, 0.0f,0.0f);

	m_pDev->SetLight( 0, &Lgt );
	m_pDev->LightEnable( 0, TRUE );
	m_pDev->SetRenderState(D3DRS_LIGHTING, TRUE);
	m_pDev->SetRenderState( D3DRS_AMBIENT, 0x000F0F0F );

	m_pDev->SetMaterial( &mtl );

	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	D3DXMATRIX mtW;
	D3DXMatrixIdentity(&mtW);

	mtW._41 = m_vcBndC.x;
	mtW._42 = m_vcBndC.y;
	mtW._43 = m_vcBndC.z;

	m_pDev->SetTransform(D3DTS_WORLD,&mtW);
	m_pMshC->DrawSubset(0);


	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);
	m_pMshR->DrawSubset(0);

	D3DXMatrixIdentity(&mtW);
	m_pDev->SetTransform(D3DTS_WORLD,&mtW);

	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
}