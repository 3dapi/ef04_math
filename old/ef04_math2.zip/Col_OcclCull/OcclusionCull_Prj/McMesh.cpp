// Implementation of the CMcMesh class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"



std::string GetPath( std::string filename )
{
	int lastSlash = filename.find_last_of( '\\' );
	
	std::string path = filename.substr( 0, lastSlash + 1 );
	return path;
}



//-----------------------------------------------------------------------------
// Name: CMcMesh()
// Desc: Constructor
//-----------------------------------------------------------------------------
CMcMesh::CMcMesh()
{
	m_pDev		= NULL;
	m_msObj		= NULL;
	m_msMtl		= NULL;
	m_msTx		= NULL;

	m_iFce	= 0L;
	m_iVtx	= 0L;
	m_iMtl	= 0L;
}




CMcMesh::~CMcMesh()
{
	Destroy();
}


INT CMcMesh::Create(PDEV pDev, CHAR* sFile)
{
	m_pDev	= pDev;
	strcpy(m_sFile, sFile);
	strcpy(m_sPath, sFile);

	char* pPath = strrchr(m_sPath, '/');
	int d = pPath - m_sPath;

	m_sPath[d] = 0;
	

	// Buffer to hold the materials in
	LPD3DXBUFFER mtrlBuffer;

	// Load the mesh from the specified file
	if( FAILED( D3DXLoadMeshFromX( m_sFile, D3DXMESH_MANAGED, m_pDev,
								  NULL, &mtrlBuffer, NULL, (DWORD*)&m_iMtl,
								  &m_msObj ) ) )
		return -1;

	// Get stats
	m_iFce = m_msObj->GetNumFaces();
	m_iVtx = m_msObj->GetNumVertices();

	// Extract material properties and texture names
	D3DXMATERIAL* materials = (D3DXMATERIAL*)mtrlBuffer->GetBufferPointer();
	m_msMtl = new D3DMATERIAL9[ m_iMtl ];
	m_msTx  = new LPDIRECT3DTEXTURE9[ m_iMtl ];

	for( DWORD i = 0; i < m_iMtl; ++i )
	{
		// Copy the material
		m_msMtl[i] = materials[i].MatD3D;

		// Set ambient colors
		m_msMtl[i].Ambient = m_msMtl[i].Diffuse;

		m_msTx[i] = NULL;

		if( materials[i].pTextureFilename != NULL && lstrlen(materials[i].pTextureFilename) > 0 )
		{
			// Find full texture path
			char sTexture[256];	
			

			sprintf(sTexture, "%s/%s", m_sPath, materials[i].pTextureFilename);

			if(FAILED(McUtil_TextureLoad(sTexture, m_msTx[i])))
				return -1;
		}
	}

	// Done with the material buffer
	SAFE_RELEASE( mtrlBuffer );

	return 1;
}



void CMcMesh::Destroy()
{
	SAFE_DELETE_ARRAY( m_msMtl	);

	
	if( m_msTx )
	{
		for(INT i = 0; i < m_iMtl; ++i)
			SAFE_RELEASE( m_msTx[i] );
	}

	SAFE_DELETE_ARRAY(	m_msTx	);
	SAFE_RELEASE( m_msObj );
}




void CMcMesh::Render(D3DXMATRIX mtWld)
{
	// Apply tranformation
	m_pDev->SetTransform( D3DTS_WORLD, &mtWld );

	for( DWORD i = 0; i < m_iMtl; ++i )
	{
		// Set the material and texture for this subset
		m_pDev->SetMaterial( &m_msMtl[i] );
		m_pDev->SetTexture( 0, m_msTx[i] );

		// Draw the subset
		m_msObj->DrawSubset( i );
	}
}





INT CMcMesh::GetNumFaces()
{
	return m_iFce;
}

INT CMcMesh::GetNumVerts()
{
	return m_iVtx;
}


