// Interface for the COcclCull class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MD2MDL_H_
#define _MD2MDL_H_


struct McObj
{
	CMcMesh*	pMesh;			// Reference to a mesh object
	CMcMesh*	pBound;			// Reference to low-poly bounding mesh

	D3DXVECTOR3		vcP;			// Translation matrix for this object
	D3DXMATRIX		mtWld;

	BOOL		bRnd;			// If true, render the object

	McObj( CMcMesh* meshRef, CMcMesh* boundMesh, D3DXVECTOR3 _vcP )
	{
		pMesh	= meshRef;
		pBound  = boundMesh;
		vcP		= _vcP;
		bRnd	= 0;
	}

	INT FrameMove()
	{
		D3DXMatrixTranslation( &mtWld, vcP.x, vcP.y, vcP.z );
		return 1;
	}

	void Render()
	{
		pMesh->Render(mtWld );
	}

	void RenderBoundingBox()
	{
		pBound->Render(mtWld );
	}

	INT GetNumVerts()
	{
		return pMesh->GetNumVerts();
	}
};


typedef std::vector<McObj>	lsObj;


class COcclCull
{
protected:
	INT			m_iVtx			;			// Number of m_iVtx rendered this frame
	INT			m_iRen			;			// Number of trees rendered this frame

	lsObj		m_lsObj			;			// Vector of m_lsObj
	CMcMesh*	m_msTerrain		;			// The terrain mesh
	CMcMesh*	m_msTree		;			// The tree mesh
	CMcMesh*	m_msTreeBound	;			// Bounding mesh for tree

	PDQR		m_pd3dQuery		;			// The query
	PDRS		m_pOccRSF		;			// Occlusion's render to surface
	PDSF		m_pOccSF		;			// Occlusion's surface that it uses
	PDTX		m_pOccTx		;			// Texture to get surface from

	BOOL		m_bCull			;
	BOOL		m_bQuery		;

public:
	COcclCull();
	virtual ~COcclCull();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();

	INT		Restore();
	void	Invalidate();

protected:
	INT		OcclusionCull();
	FLOAT	GetRandom();
};


#endif