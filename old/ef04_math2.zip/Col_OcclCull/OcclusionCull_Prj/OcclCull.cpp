// Implementation of the COcclCull class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


COcclCull::COcclCull()
{
	m_msTerrain		= NULL;
	m_msTree		= NULL;
	m_msTreeBound	= NULL;

	m_pd3dQuery		= NULL;
	m_pOccRSF		= NULL;
	m_pOccSF		= NULL;
	m_pOccTx		= NULL;

	m_iVtx		= 0;
	m_iRen		= 0;

	m_bCull		= 1;
}


COcclCull::~COcclCull()
{
	Destroy();
}



INT COcclCull::Init()
{
	// Load the meshes
	m_msTerrain = new CMcMesh;
	if( FAILED( m_msTerrain->Create( GDEVICE, "Model/terrain.x" ) ) )
		return -1;

	m_msTree = new CMcMesh;
	if( FAILED( m_msTree->Create( GDEVICE, "Model/tree.x" ) ) )
		return -1;

	m_msTreeBound = new CMcMesh;
	if( FAILED( m_msTreeBound->Create( GDEVICE, "Model/tree_bounding.x" ) ) )
		return -1;



	for(int i=0; i<600; ++i)
	{
		// 150 is the width and length of the terrain plane
		D3DXVECTOR3 pos = D3DXVECTOR3( GetRandom() * 150.0f, 12.0f, GetRandom() * 150.0f );
		m_lsObj.push_back( McObj( m_msTree, m_msTreeBound, pos ) );
	};


	return 1;
}

void COcclCull::Destroy()
{
	SAFE_DELETE( m_msTerrain );
	SAFE_DELETE( m_msTree );
	SAFE_DELETE( m_msTreeBound );
}


int COcclCull::Restore()
{

	if (D3DERR_NOTAVAILABLE == GDEVICE->CreateQuery (D3DQUERYTYPE_OCCLUSION, NULL))
	{
		m_bQuery = FALSE;
	}
	else
	{
		m_bQuery = TRUE;
	}

	// Create the query if we can
	if (m_bQuery)
	{
		GDEVICE->CreateQuery( D3DQUERYTYPE_OCCLUSION, &m_pd3dQuery );
	}




	// Get the display mode to obtain the format
	D3DDISPLAYMODE mode;
	GDEVICE->GetDisplayMode( 0, &mode );

	// Create the texture first, so we can get access to it's surface
	if( FAILED( D3DXCreateTexture( GDEVICE, 160, 120, 1, D3DUSAGE_RENDERTARGET,
		mode.Format, D3DPOOL_DEFAULT, &m_pOccTx ) ) )
	{
		return -1;
	}

	// Obtain the surface (what we really need)
	D3DSURFACE_DESC desc;
	m_pOccTx->GetSurfaceLevel(0, &m_pOccSF);
	m_pOccSF->GetDesc(&desc);

	// Create the render to surface
	if( FAILED( D3DXCreateRenderToSurface( GDEVICE, desc.Width, desc.Height, desc.Format, TRUE, D3DFMT_D16, &m_pOccRSF ) ) )
		return -1;

	return 1;
}


void COcclCull::Invalidate()
{
	SAFE_RELEASE( m_pOccTx );
	SAFE_RELEASE( m_pOccSF );
	SAFE_RELEASE( m_pOccRSF );
	SAFE_RELEASE( m_pd3dQuery );
}


int COcclCull::FrameMove()
{
	if(pInput->GetKey(VK_F1))
	{
		m_bCull ^=1;
	}


	for(int i = 0; i < m_lsObj.size(); i++ )
	{
		m_lsObj[i].FrameMove();
	}


	// Cull the m_lsObj
	if(m_bCull)
		OcclusionCull();

	return 1;
}


void COcclCull::Render()
{
	m_iVtx	= 0;
	m_iRen	= 0;

	// Render the skybox first
	// Set sampler state to clamp
	GDEVICE->SetRenderState( D3DRS_DITHERENABLE,   FALSE );
	GDEVICE->SetRenderState( D3DRS_SPECULARENABLE, FALSE );
	GDEVICE->SetRenderState( D3DRS_ZENABLE, D3DZB_TRUE  );

	GDEVICE->SetRenderState( D3DRS_LIGHTING, FALSE );

	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_SRCBLENDALPHA, D3DBLEND_SRCCOLOR);
	GDEVICE->SetRenderState(D3DRS_DESTBLENDALPHA, D3DBLEND_DESTCOLOR);


	GDEVICE->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );



	GDEVICE->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	GDEVICE->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
	GDEVICE->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
	GDEVICE->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );

	// Turn clamping off, back to wrap
	GDEVICE->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
	GDEVICE->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );

	// Render the terrain plane
	D3DXMATRIX	mtWld;

	D3DXMatrixIdentity(&mtWld);

	m_msTerrain->Render(mtWld);

	for( int i = 0; i < m_lsObj.size(); i++ )
	{
		if(m_bCull)
		{
			if( m_lsObj[i].bRnd )
			{
				m_lsObj[i].Render();
				m_iVtx += m_lsObj[i].GetNumVerts();
				m_iRen++;
			}
		}

		else
		{
			m_lsObj[i].Render();
			m_iVtx += m_lsObj[i].GetNumVerts();
			m_iRen++;
		}
	}



	CHAR	sMsg[512];
	RECT	rc={10,50, 400, 70};

	sprintf(sMsg, "Vertex:%d RenderObject:%d cull?%d", m_iVtx, m_iRen, m_bCull);

	GMAIN->m_pD3DXFont->DrawText( sMsg, -1, &rc, 0, D3DXCOLOR(1,0,1,1) );
}






float COcclCull::GetRandom()
{
	float random = (float)rand() / RAND_MAX;

	if( random < 0.5f )
		random = -random * 2;
	else
		random = (1.0f - random) * 2;

	return random;
}



INT COcclCull::OcclusionCull()
{
	if( FAILED( m_pOccRSF->BeginScene( m_pOccSF, NULL ) ) )
		return -1;

	GDEVICE->Clear(0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB( 0, 0, 0 ), 1.0f, 0);

	// ��� ��ü�� �ٿ�� �ڽ��� �׸���.
	for( int i = 0; i < m_lsObj.size(); i++ )
	{
		m_lsObj[i].RenderBoundingBox();
	}

	// Now, render each box again, except this time, count how many pixels are visible
	// by using an occlusion query.  We are guaranteed to get the right amount,
	// since all the bounding boxes have already been rendered

	for(i = 0; i < m_lsObj.size(); i++ )
	{
		// Start the query

		if (m_bQuery)
		{
			m_pd3dQuery->Issue( D3DISSUE_BEGIN );
		}

		// Render
		m_lsObj[i].RenderBoundingBox();



		DWORD pixelsVisible = 0;

		if (m_bQuery)
		{
			// End the query, get the data
			m_pd3dQuery->Issue(D3DISSUE_END);

			// Loop until the data becomes available
			while (m_pd3dQuery->GetData((void *) &pixelsVisible, sizeof(DWORD), D3DGETDATA_FLUSH) == S_FALSE);
		}

		if( pixelsVisible == 0 )
			m_lsObj[i].bRnd = pixelsVisible;	// No pixels visible, do not render
		else
			m_lsObj[i].bRnd = pixelsVisible;	// Pixels visible, render

	}

	// End the occlusion render scene
	m_pOccRSF->EndScene( 0 );

	// User is pressing the 'M' key, save this buffer to .BMP file
	if(pInput->GetKey(VK_M))
		D3DXSaveSurfaceToFile( "buffer.bmp", D3DXIFF_BMP, m_pOccSF, NULL, NULL );

	return 1;
}