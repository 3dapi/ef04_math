//-----------------------------------------------------------------------------
// Name: Main.cpp   
// Desc: Direct3D9 Occlusion Culling Tutorial
// Copyright: Dustin Franklin, 2004
// Contact:   dustinhimer@comcast.net
// http://www.gamedev.net/reference/articles/article2128.asp
//-----------------------------------------------------------------------------

#define STRICT
#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>
#include <dinput.h>
#include <string>
#include <sstream>
#include <vector>
#include <time.h>
#include "CFont.h"
#include "CMesh.h"



//-----------------------------------------------------------------------------
// Defines
//-----------------------------------------------------------------------------
#define APP_TITLE "Occlusion Culling"
#define APP_WIDTH  1024
#define APP_HEIGHT 768

#define NUM_TREES 300

#define SafeRelease(pInterface) if(pInterface != NULL) {pInterface->Release(); pInterface=NULL;}
#define SafeDelete(pObject) if(pObject != NULL) {delete pObject; pObject=NULL;}
#define SafeDeleteArray(pArray) { if(pArray) { delete[] (pArray);   (pArray)=NULL; } }

#define AdjustRand( rand ) rand = rand < .5f ? -rand : rand;



//-----------------------------------------------------------------------------
// Structures
//-----------------------------------------------------------------------------
struct SCamera 
{ 
	D3DXVECTOR3 pos; 

	float pitch; 
	float yaw; 
	float roll; 
};

struct SObject
{
	CMesh* meshReference;		// Reference to a mesh object
	CMesh* boundingMesh;		// Reference to low-poly bounding mesh

	D3DXVECTOR3 pos;			// Position of this object
	D3DXMATRIX  matTranslate;	// Translation matrix for this object

	bool render;				// If true, render the object
	float distanceToCamera;		// The distance to the camera (player position)

	SObject( CMesh* meshRef, CMesh* boundMesh, D3DXVECTOR3 position )
	{
		meshReference = meshRef; 
		boundingMesh  = boundMesh;
		pos = position;
		render = false;
		distanceToCamera = 0.0f;
	}
};



//-----------------------------------------------------------------------------
// Prototypes
//-----------------------------------------------------------------------------
HRESULT InitD3D();
HRESULT InitGeometry();
HRESULT Cleanup();

HRESULT Render();
HRESULT RenderText();

HRESULT OcclusionCull();
HRESULT SetupOcclusion();

HRESULT SetupMatrices();
HRESULT SetupStates();

HRESULT Reset();
HRESULT SizeChange();

HRESULT UpdateStats();

float GetTime();
float GetRandom();

inline float Distance( float x1, float y1, float z1, float x2, float y2, float z2 );
void DistanceSort( std::vector<SObject> objectArray, int lBound, int uBound );



//-----------------------------------------------------------------------------
// Globals
//-----------------------------------------------------------------------------
// Variables
bool    keys[256];				// Buffer for keys
float	fps			= 300.0f;	// The frames per second

DWORD   verts		= 0;		// Number of verts rendered this frame
int     objectsRendered = 0;	// Number of trees rendered this frame

SCamera camera;					// Camera structure

std::vector<SObject> objects;	// Vector of objects
CMesh* terrain   = NULL;		// The terrain mesh
CMesh* tree      = NULL;		// The tree mesh
CMesh* treeBound = NULL;		// Bounding mesh for tree
CMesh* skybox    = NULL;

// Objects
LPDIRECT3D9			  d3dObject;			// Direct3D Object
LPDIRECT3DDEVICE9	  d3dDevice;			// Direct3D Device

LPDIRECT3DQUERY9		d3dQuery;				// The query
LPD3DXRENDERTOSURFACE	occlusionRender;	// Occlusion's render to surface
LPDIRECT3DSURFACE9      occlusionSurface;	// Occlusion's surface that it uses
LPDIRECT3DTEXTURE9      occlusionTexture;	// Texture to get surface from

D3DPRESENT_PARAMETERS	d3dpp;				// Presentation parameters
D3DXMATRIX				matOrientation;		// Orientation matrix

HWND hWnd;									// HWND of the window

CD3DFont*			  font = NULL;			// Main font
std::ostringstream	  ss;					// String writer stream



//-----------------------------------------------------------------------------
// Name: SetupOcclusion()
// Desc: Create the objects needed for the occlusion culling
//-----------------------------------------------------------------------------
HRESULT SetupOcclusion()
{
	// Create the query
	d3dDevice->CreateQuery( D3DQUERYTYPE_OCCLUSION, &d3dQuery );

	// Get the display mode to obtain the format
	D3DDISPLAYMODE mode;
    d3dDevice->GetDisplayMode( 0, &mode );

	// Create the texture first, so we can get access to it's surface
	if( FAILED( D3DXCreateTexture( d3dDevice, 320, 240, 1, D3DUSAGE_RENDERTARGET,
						   mode.Format, D3DPOOL_DEFAULT, &occlusionTexture ) ) )
	{
		return E_FAIL;
	}

	// Obtain the surface (what we really need)
	D3DSURFACE_DESC desc;
    occlusionTexture->GetSurfaceLevel(0, &occlusionSurface);
    occlusionSurface->GetDesc(&desc);

	// Create the render to surface
	if( FAILED( D3DXCreateRenderToSurface( d3dDevice, desc.Width, desc.Height, desc.Format,
										   TRUE, D3DFMT_D16, &occlusionRender ) ) )
	{
		return E_FAIL;
	}

	return S_OK;
}



//-----------------------------------------------------------------------------
// Name: OcclusionCull()
// Desc: Cull the objects
//-----------------------------------------------------------------------------
HRESULT OcclusionCull()
{
	// Begin occlusionRender
	if( SUCCEEDED( occlusionRender->BeginScene( occlusionSurface, NULL ) ) )
	{
		// Clear the occlusionRender's surface
		d3dDevice->Clear(0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB( 200, 200, 200 ), 1.0f, 0);	

		// First, render every object's bounding box
		for( int i = 0; i < objects.size(); i++ )
		{
			objects[i].boundingMesh->Render( d3dDevice, objects[i].matTranslate );
		}

		// Now, render each box again, except this time, count how many pixels are visible
		// by using an occlusion query.  We are guaranteed to get the right amount, 
		// since all the bounding boxes have already been rendered

		for(i = 0; i < objects.size(); i++ )
		{
			// Start the query
			d3dQuery->Issue( D3DISSUE_BEGIN );

			// Render
			objects[i].boundingMesh->Render( d3dDevice, objects[i].matTranslate );

			// End the query, get the data
			d3dQuery->Issue( D3DISSUE_END );

			// Loop until the data becomes available
			DWORD pixelsVisible = 0;
			while (d3dQuery->GetData((void *) &pixelsVisible, sizeof(DWORD), D3DGETDATA_FLUSH) == S_FALSE);
			
			if( pixelsVisible == 0 )
				objects[i].render = false;	// No pixels visible, do not render
			else
				objects[i].render = true;	// Pixels visible, render
			
		}

		// End the occlusion render scene
		occlusionRender->EndScene( 0 );

		// User is pressing the 'M' key, save this buffer to .BMP file
		if( keys['M'] )
			D3DXSaveSurfaceToFile( "buffer.bmp", D3DXIFF_BMP, occlusionSurface, NULL, NULL );
	}

	return S_OK;
}



//-----------------------------------------------------------------------------
// Name: InitD3D()
// Desc: Initialize graphics
//-----------------------------------------------------------------------------
HRESULT InitD3D()
{
	if( NULL == ( d3dObject = Direct3DCreate9( D3D_SDK_VERSION ) ) )
		return E_FAIL;

	// Presentation params
    ZeroMemory( &d3dpp, sizeof(d3dpp) );

    d3dpp.Windowed					= TRUE;
    d3dpp.SwapEffect				= D3DSWAPEFFECT_DISCARD;
    d3dpp.BackBufferFormat			= D3DFMT_UNKNOWN;
    d3dpp.EnableAutoDepthStencil	= TRUE;
    d3dpp.AutoDepthStencilFormat	= D3DFMT_D16;
	d3dpp.BackBufferWidth			= APP_WIDTH;
	d3dpp.BackBufferHeight			= APP_HEIGHT;
	d3dpp.PresentationInterval		= D3DPRESENT_INTERVAL_IMMEDIATE;

	// Create the D3DDevice
    if( FAILED( d3dObject->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
										 D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                                         &d3dpp, &d3dDevice ) ) )
    {
        return E_FAIL;
    }

	if( FAILED( SetupOcclusion() ) )
		return E_FAIL;

	SetupStates();

	return S_OK;
}



//-----------------------------------------------------------------------------
// Name: InitGeometry()
// Desc: Initialize all models, meshes, vertices, ect...
//-----------------------------------------------------------------------------
HRESULT InitGeometry()
{
	// Load the meshes
	terrain = new CMesh();
	if( FAILED( terrain->Create( d3dDevice, "Materials\\terrain.x" ) ) )
		return E_FAIL;

	skybox = new CMesh();
	if( FAILED( skybox->Create( d3dDevice, "Materials\\skybox.x" ) ) )
		return E_FAIL;

	tree = new CMesh();
	if( FAILED( tree->Create( d3dDevice, "Materials\\tree.x" ) ) )
		return E_FAIL;

	treeBound = new CMesh();
	if( FAILED( treeBound->Create( d3dDevice, "Materials\\tree_bounding.x" ) ) )
		return E_FAIL;

	// Populate the object list
	// Randomly place trees on terrain
	srand( (unsigned)time( NULL ) );	// Seed random number generator

	for( int i = 0; i < NUM_TREES; i++ )
	{
		// 150 is the width and length of the terrain plane
		D3DXVECTOR3 pos = D3DXVECTOR3( GetRandom() * 150.0f, 12.0f, GetRandom() * 150.0f );
		objects.push_back( SObject( tree, treeBound, pos ) );
	};

	// Setup default camera pos
	camera.pos = D3DXVECTOR3( 0.0f, 10.0f, 0.0f );

	// Init font
	font = new CD3DFont( "Verdana", 8 );
	if( FAILED( font->InitDeviceObjects( d3dDevice ) ) )
		return E_FAIL;
	
	return S_OK;
}



//-----------------------------------------------------------------------------
// Name: Cleanup()
// Desc: Destroy all the objects
//-----------------------------------------------------------------------------
HRESULT Cleanup()
{
	skybox->Destroy();
	SafeDelete( skybox );

	terrain->Destroy();
	SafeDelete( terrain );

	tree->Destroy();
	SafeDelete( tree );

	treeBound->Destroy();
	SafeDelete( treeBound );
	
	font->InvalidateDeviceObjects();
	SafeDelete( font );

	SafeRelease( occlusionTexture );
	SafeRelease( occlusionSurface );
	SafeRelease( occlusionRender );
	SafeRelease( d3dQuery );

	SafeRelease( d3dDevice );
	SafeRelease( d3dObject );

	return S_OK;
}



//-----------------------------------------------------------------------------
// Name: SizeChange()
// Desc: Reset the device and handle the potential size change
//-----------------------------------------------------------------------------
HRESULT SizeChange()
{
	HRESULT hr;

	RECT newRect;
	GetClientRect( hWnd, &newRect );

	// Check to see if the dimensions are different
	if( d3dpp.BackBufferWidth  != (newRect.right - newRect.left ) ||
		d3dpp.BackBufferHeight != (newRect.bottom - newRect.top ) )
	{
		d3dpp.BackBufferWidth  = newRect.right - newRect.left;
		d3dpp.BackBufferHeight = newRect.bottom - newRect.top;
	}
	else
	{
		// Dimensions didn't change, we're ok
		return S_OK;
	}
	
	if( d3dDevice )
		hr = Reset();

	return hr;
}



//-----------------------------------------------------------------------------
// Name: Reset()
// Desc: Reset the LPDIRECT3DDEVICE9 object when it is lost
//-----------------------------------------------------------------------------
HRESULT Reset()
{
	// Invalidate device objects
	SafeRelease( occlusionTexture );
	SafeRelease( occlusionSurface );
	SafeRelease( occlusionRender );
	SafeRelease( d3dQuery );
	font->InvalidateDeviceObjects();

	if( FAILED( d3dDevice->Reset( &d3dpp ) ) )
		return E_FAIL;

	// Re-aquire device objects
	font->InitDeviceObjects( d3dDevice );
	
	// Re-aquire occlusion objects
	if( FAILED( SetupOcclusion() ) )
		return E_FAIL;

	SetupStates();

	return S_OK;
}



//-----------------------------------------------------------------------------
// Name: SetupStates()
// Desc: Setup renderstates
//-----------------------------------------------------------------------------
HRESULT SetupStates()
{
	d3dDevice->SetRenderState( D3DRS_DITHERENABLE,   FALSE );
    d3dDevice->SetRenderState( D3DRS_SPECULARENABLE, FALSE );
	d3dDevice->SetRenderState( D3DRS_ZENABLE, D3DZB_TRUE  ); 
    d3dDevice->SetRenderState( D3DRS_AMBIENT, D3DCOLOR_XRGB( 255, 255, 255 ) );
	d3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE );
     
	d3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    d3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    d3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
    d3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
    d3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
    d3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
    d3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    d3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
	
    d3dDevice->SetRenderState( D3DRS_LIGHTING, FALSE ); 
	
	return S_OK;
}



//-----------------------------------------------------------------------------
// Name: SetupMatrices()
// Desc: Setup the projection and viewing matrix
//-----------------------------------------------------------------------------
HRESULT SetupMatrices()
{
	float adjust = (float)1/fps;

	// Update camera with input
	D3DXVECTOR3 cameraVel = D3DXVECTOR3( 0, 0, 0 );
	if( keys['W'] )
		cameraVel.z = 15.0f * adjust;
	else if( keys['S'] )
		cameraVel.z = -15.0f * adjust;

	if( keys['A'] )
		cameraVel.x = -15.0f * adjust;
	else if( keys['D'] )
		cameraVel.x = 15.0f * adjust;

	if( keys['J'] )
		camera.yaw -= 0.51f * adjust;
	else if( keys['L'] )
		camera.yaw += 0.51f * adjust;

	if( keys['K'] )
		camera.pitch += 0.51f * adjust;
	else if( keys['I'] )
		camera.pitch -= 0.51f * adjust;

	D3DXVec3TransformNormal( &cameraVel, &cameraVel, &matOrientation );
	camera.pos += cameraVel;

	// Build quaternion and transform matrix
	D3DXQUATERNION qR;
	D3DXMATRIX matView;
    D3DXQuaternionRotationYawPitchRoll( &qR, camera.yaw, camera.pitch, camera.roll );
    D3DXMatrixAffineTransformation( &matOrientation, 1.25f, NULL, &qR, &camera.pos );
    D3DXMatrixInverse( &matView, NULL, &matOrientation );
    d3dDevice->SetTransform( D3DTS_VIEW, &matView );

    // Projection matrix
    D3DXMATRIXA16 matProj;
	float aspect = (float)d3dpp.BackBufferWidth / d3dpp.BackBufferHeight;
    D3DXMatrixPerspectiveFovLH( &matProj, D3DX_PI/4, aspect, 1.0f, 1000.0f );
    d3dDevice->SetTransform( D3DTS_PROJECTION, &matProj );

	// Build every objects matrix, according to it's position this frame
	for( int i = 0; i < objects.size(); i++ )
	{
		D3DXMatrixTranslation( &objects[i].matTranslate, objects[i].pos.x,
								objects[i].pos.y, objects[i].pos.z );
	}

	return S_OK;
}



//-----------------------------------------------------------------------------
// Name: Render
// Desc: Render a frame
//-----------------------------------------------------------------------------
HRESULT Render()
{
	verts = 0;				// Reset vertex counter
	objectsRendered = 0;	// Reset tree count

	// Setup the matrices for this frame
    SetupMatrices();

	// Cull the objects
	OcclusionCull();

    if( SUCCEEDED( d3dDevice->BeginScene() ) )
    {
		// Clear
	    d3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(255,0,0), 1.0f, 0 );

		// Render the skybox first
		// Set sampler state to clamp
		d3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
		d3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );
		skybox->Render( d3dDevice, D3DXVECTOR3( 0.0f, 0.0f, 0.0f ) );

		// Turn clamping off, back to wrap
		d3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
		d3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );

		// Render the terrain plane
		terrain->Render( d3dDevice, D3DXVECTOR3( 0.0f, 0.0f, 0.0f ) );

		// Render the appropriate objects
		for( int i = 0; i < objects.size(); i++ )
		{
			if( objects[i].render )
			{
				objects[i].meshReference->Render( d3dDevice, objects[i].matTranslate );
				verts += objects[i].meshReference->GetNumVerts();
				objectsRendered++;
			}
		}

		RenderText();
        d3dDevice->EndScene();
    }

    // Present 
    d3dDevice->Present( NULL, NULL, NULL, NULL );

	UpdateStats();

	return S_OK;
}



//-----------------------------------------------------------------------------
// Name: RenderText
// Desc: Render text to the screen
//-----------------------------------------------------------------------------
HRESULT RenderText()
{
	D3DCOLOR fontColor = D3DCOLOR_ARGB( 245, 255, 255, 255 );
	D3DCOLOR helpColor = D3DCOLOR_ARGB( 255, 230, 240, 20 );
	
	ss.str( "" );
	ss << "FPS:  " << fps << std::endl;
	ss << "Camera:  ( " << camera.pos.x << ", " << camera.pos.y << ", " << camera.pos.z << " )" << std::endl;
	ss << "Verts Rendered:  " << verts << std::endl;
	ss << "Objects Rendered:  " << objectsRendered << std::endl;

	font->DrawText( 10, 10, fontColor, ss.str().c_str() );

	ss.str( "" );
	ss << "Controls: \n WASD: Slide Camera\n IJKL: Rotate Camera\n M: Save Occlusion Buffer";

	font->DrawText( 10, d3dpp.BackBufferHeight - 65, helpColor, ss.str().c_str() );

	return S_OK;
}



//-----------------------------------------------------------------------------
// Name: UpdateStats()
// Desc: Update the frame stats, such as FPS
//-----------------------------------------------------------------------------
HRESULT UpdateStats()
{
	static float lastTime = GetTime();
	static int frameCount = 1;	// Set to 1 to avoid any possible devide by 0
	
	// Only update FPS once per second
	float timeDif = GetTime() - lastTime;

	if( timeDif > 1.0f )
	{
		fps = frameCount;

		frameCount = 1;
		lastTime   = GetTime();
	}

	frameCount++;

	return S_OK;
}



//-----------------------------------------------------------------------------
// Name: GetTime()
// Desc: Returns the current program time, using QueryPerformanceCounter
//-----------------------------------------------------------------------------
float GetTime()
{
	static bool		counterCreated = false;
	static LONGLONG ticksPerSec = 0;
	LARGE_INTEGER	absTime;

	if( counterCreated == false )
	{
		LARGE_INTEGER qwTicksPerSec;
		QueryPerformanceFrequency( &qwTicksPerSec );
		ticksPerSec = qwTicksPerSec.QuadPart;

		counterCreated = true;
	}
	
	QueryPerformanceCounter( &absTime );

	float time = absTime.QuadPart / (double) ticksPerSec;
	
	return time;
}



//-----------------------------------------------------------------------------
// Name: GetRandom()
// Desc: Gets positive or negative random number (remember to seed using srand)
//-----------------------------------------------------------------------------
float GetRandom()
{
	float random = (float)rand() / RAND_MAX;

	if( random < 0.5f )
		random = -random * 2;
	else
		random = (1.0f - random) * 2;

	return random;
}



//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: The window's message handler
//-----------------------------------------------------------------------------
LRESULT WINAPI MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
		case WM_KEYDOWN:
			keys[wParam] = true;
			break;

		case WM_KEYUP:
			keys[wParam] = false;
			break;
			
		case WM_SIZE:
			if( wParam == SIZE_MAXIMIZED || wParam == SIZE_RESTORED )
				SizeChange();
			break;

		case WM_EXITSIZEMOVE:
			SizeChange();
			break;

        case WM_DESTROY:
            Cleanup();
            PostQuitMessage( 0 );
            return 0;
    }

    return DefWindowProc( hWnd, msg, wParam, lParam );
}




//-----------------------------------------------------------------------------
// Name: WinMain()
// Desc: The application's entry point
//-----------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    // Register the window class
    WNDCLASSEX wc = { sizeof(WNDCLASSEX), CS_CLASSDC, MsgProc, 0L, 0L, 
                      GetModuleHandle(NULL), NULL, NULL, NULL, NULL,
                      APP_TITLE, NULL };
    RegisterClassEx( &wc );

    // Create the application's window
    hWnd = CreateWindow( APP_TITLE, APP_TITLE, 
                         WS_OVERLAPPEDWINDOW, 0, 0, APP_WIDTH, APP_HEIGHT,
                         GetDesktopWindow(), NULL, wc.hInstance, NULL );

    // Initialize Direct3D
    if( SUCCEEDED( InitD3D() ) )
    { 
        // Create the scene geometry
        if( SUCCEEDED( InitGeometry() ) )
        {
            // Show the window
            ShowWindow( hWnd, SW_SHOWDEFAULT );
            UpdateWindow( hWnd );

            // Enter the message loop
            MSG msg; 
            ZeroMemory( &msg, sizeof(msg) );
            while( msg.message!=WM_QUIT )
            {
                if( PeekMessage( &msg, NULL, 0U, 0U, PM_REMOVE ) )
                {
                    TranslateMessage( &msg );
                    DispatchMessage( &msg );
                }
                else
                    Render();
            }
        }
    }

    UnregisterClass( APP_TITLE, wc.hInstance );
    return 0;
}