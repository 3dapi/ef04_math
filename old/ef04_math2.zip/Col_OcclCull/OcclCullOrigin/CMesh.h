//-----------------------------------------------------------------------------
// Name: CMesh.h
// Desc: Declaration for CMesh class
//-----------------------------------------------------------------------------

#ifndef CMESH_H
#define CMESH_H

#include <d3d9.h>
#include <d3dx9.h>
#include <string>



//-------------------------------------------------------------------------
// Name: class CMesh
// Desc: Loads and renders meshes
//-------------------------------------------------------------------------
class CMesh
{
	// Variables
	DWORD			    numMaterials;	// Number of materials
	static const DWORD  MESHFVF;

	std::string			filename;
	std::string			path;

	DWORD				numFaces;		// Number of faces
	DWORD				numVerts;		// Number of vertices

	// Objects
	D3DMATERIAL9*		meshMaterials;	// Materials for mesh
	LPDIRECT3DTEXTURE9* meshTextures;	// Textures for mesh
	LPD3DXMESH			meshObject;		// D3DX Mesh object

public:
	
	DWORD GetNumFaces() { return numFaces; }
	DWORD GetNumVerts() { return numVerts; }
	DWORD GetNumMaterials() { return numMaterials; }

	// Functions
	CMesh();

	HRESULT Create( LPDIRECT3DDEVICE9 d3dDevice, std::string file );
	HRESULT Destroy();
	HRESULT Render( LPDIRECT3DDEVICE9 d3dDevice, D3DXVECTOR3 pos );
	HRESULT Render( LPDIRECT3DDEVICE9 d3dDevice, D3DXMATRIX matPos );
};


#endif