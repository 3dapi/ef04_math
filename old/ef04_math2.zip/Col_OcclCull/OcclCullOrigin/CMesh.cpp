//-----------------------------------------------------------------------------
// Name: CMesh.cpp
// Desc: Creates, renders, and transforms meshes
//-----------------------------------------------------------------------------

#define STRICT
#include <windows.h>
#include <string>
#include "CMesh.h"


const DWORD CMesh::MESHFVF = D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1;

#define SafeRelease(pInterface) if(pInterface != NULL) {pInterface->Release(); pInterface=NULL;}
#define SafeDelete(pObject) if(pObject != NULL) {delete pObject; pObject=NULL;}
#define SafeDeleteArray(pArray) { if(pArray) { delete[] (pArray);   (pArray)=NULL; } }



//-----------------------------------------------------------------------------
// Name: GetPath()
// Desc: Returns the path of a file (excluding the filename, but with a \ on the end)
//-----------------------------------------------------------------------------
std::string GetPath( std::string filename )
{
	int lastSlash = filename.find_last_of( '\\' );
	
	std::string path = filename.substr( 0, lastSlash + 1 );
	return path;
}



//-----------------------------------------------------------------------------
// Name: CMesh()
// Desc: Constructor
//-----------------------------------------------------------------------------
CMesh::CMesh()
{
	meshObject		= NULL;
	meshMaterials	= NULL;
	meshTextures	= NULL;

	numFaces		= 0L;
	numVerts		= 0L;
	numMaterials	= 0L;
}



//-----------------------------------------------------------------------------
// Name: Create()
// Desc: Loads the mesh from file, creates mesh object, materials and textures
//-----------------------------------------------------------------------------
HRESULT CMesh::Create( LPDIRECT3DDEVICE9 d3dDevice, std::string file )
{
	filename = file;
	path     = GetPath( filename );

	// Buffer to hold the materials in
	LPD3DXBUFFER mtrlBuffer;

	// Load the mesh from the specified file
	if( FAILED( D3DXLoadMeshFromX( filename.c_str(), D3DXMESH_SYSTEMMEM, d3dDevice,
								  NULL, &mtrlBuffer, NULL, &numMaterials,
								  &meshObject ) ) )
		return E_FAIL;

	// Get stats
	numFaces = meshObject->GetNumFaces();
	numVerts = meshObject->GetNumVertices();

	// Extract material properties and texture names
	D3DXMATERIAL* materials = (D3DXMATERIAL*)mtrlBuffer->GetBufferPointer();
	meshMaterials = new D3DMATERIAL9[ numMaterials ];
	meshTextures  = new LPDIRECT3DTEXTURE9[ numMaterials ];

	for( DWORD i = 0; i < numMaterials; i++ )
	{
		// Copy the material
		meshMaterials[i] = materials[i].MatD3D;

		// Set ambient colors
		meshMaterials[i].Ambient = meshMaterials[i].Diffuse;

		meshTextures[i] = NULL;

		if( materials[i].pTextureFilename != NULL && lstrlen(materials[i].pTextureFilename) > 0 )
		{
			// Find full texture path
			std::string texturePath = path + materials[i].pTextureFilename;

			// Load texture
			if( FAILED( D3DXCreateTextureFromFile( d3dDevice, texturePath.c_str(),
												   &meshTextures[i] ) ) )
				return E_FAIL;
		}
	}

	// Done with the material buffer
	SafeRelease( mtrlBuffer );

	return S_OK;
}



//-----------------------------------------------------------------------------
// Name: Destroy()
// Desc: Cleanup all the objects created
//-----------------------------------------------------------------------------
HRESULT CMesh::Destroy()
{
	if( meshMaterials != NULL )
		delete[] meshMaterials;

	if( meshTextures )
	{
		for( DWORD i = 0; i < numMaterials; i++ )
			SafeRelease( meshTextures[i] );

		delete[] meshTextures;
	}

	SafeRelease( meshObject );

	return S_OK;

}



//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Tranforms the mesh, then renders it
//-----------------------------------------------------------------------------
HRESULT CMesh::Render( LPDIRECT3DDEVICE9 d3dDevice, D3DXMATRIX matPos )
{
	// Apply tranformation
	d3dDevice->SetTransform( D3DTS_WORLD, &matPos );

	// Now render
	for( DWORD i = 0; i < numMaterials; i++ )
	{
		// Set the material and texture for this subset
		d3dDevice->SetMaterial( &meshMaterials[i] );
		d3dDevice->SetTexture( 0, meshTextures[i] );

		// Draw the subset
		meshObject->DrawSubset( i );
	}

	return S_OK;
}


//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Tranforms the mesh, then renders it
//-----------------------------------------------------------------------------
HRESULT CMesh::Render( LPDIRECT3DDEVICE9 d3dDevice, D3DXVECTOR3 pos )
{
	// Translate first
	D3DXMATRIX matTranslate;
	D3DXMatrixTranslation( &matTranslate, pos.x, pos.y, pos.z );
	return Render( d3dDevice, matTranslate );
}


