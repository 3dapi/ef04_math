// Implementation of the COrbit class.
// http://www.mvps.org/directx/articles/rayproj.htm
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


COrbit::COrbit(ID3DXMesh *pMesh,float fDist,D3DXVECTOR3 vAxis,float fRot,float fVel)
:CObj(pMesh)
{
	// save parameters
	m_fDist=fDist;
	m_vAxis=vAxis;
	m_fRot=fRot;
	m_fVel=fVel;
}

COrbit::~COrbit()
{

}

void COrbit::FrameMove(float fElapsed)
{
	// increment rotations
	m_fRot+=m_fVel*fElapsed;

	// create transformation matrix
	D3DXMATRIX mat;
	D3DXMatrixRotationAxis(&mat,&m_vAxis,m_fRot);
	D3DXVECTOR3 v;
	D3DXVec3TransformNormal(&v,&D3DXVECTOR3(0.0f,0.0f,m_fDist),&mat);
	D3DXMatrixTranslation(&m_worldMat,v.x,v.y,v.z);

	// move children and siblings
	if (m_pChild)
		m_pChild->FrameMove(fElapsed);
	if (m_pSibling)
		m_pSibling->FrameMove(fElapsed);
}
