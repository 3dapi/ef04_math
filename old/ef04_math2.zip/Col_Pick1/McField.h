// Interface for the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCFIELD_H_
#define _MCFIELD_H_

class CMcField
{
protected:
	VtxD*		m_pLine;
	VtxDUV1		m_pVtx[4];

	PDTX		m_pTx;
	
public:
	CMcField();
	~CMcField();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif