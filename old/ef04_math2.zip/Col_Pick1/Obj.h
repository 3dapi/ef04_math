// Interface for the CObj class.
// http://www.mvps.org/directx/articles/rayproj.htm
////////////////////////////////////////////////////////////////////////////////

#ifndef _OBJ_H_
#define _OBJ_H_


class CObj  
{
public:
	BOOL	m_bHit;
	float	m_fHitDist;
	CObj*	m_pChild;
	CObj*	m_pSibling;

	D3DXMATRIX m_worldMat;
	D3DXMATRIX m_combinedMat;

	ID3DXMesh*	m_pMesh;
	CObj*		m_pParent;

public:
	CObj(ID3DXMesh *pMesh=NULL);
	virtual ~CObj();

	virtual void FrameMove(float fElapsed);
	void Render(D3DXMATRIX *pMat=NULL);
	CObj *Pick(D3DXVECTOR3 *pvNear,D3DXVECTOR3 *pvDir,float maxDist,CObj *pObj=NULL);
	void AddSibling(CObj *pObj);
	void AddChild(CObj *pObj);
};

#endif