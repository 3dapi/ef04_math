// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pD3DXFont		= NULL;
	m_pInput		= NULL;
	m_pCam			= NULL;

	m_pField		= NULL;
	
	m_bSolid		= TRUE;
	m_nCull			= 1;
	m_bTx			= 1;

	m_pScene		= NULL;
	m_bPauseAnimation=FALSE;
}


HRESULT CMain::Init()
{
	LOGFONT hFont =
	{
		14, 0, 0, 0, FW_BOLD, 0, 0, 0
		,	ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS
		,	ANTIALIASED_QUALITY, FF_DONTCARE, "����ü"
	};

	if( FAILED( D3DXCreateFontIndirect(GDEVICE, &hFont, &m_pD3DXFont) ) )
		return -1;

	SAFE_NEWINIT(	m_pInput,	CMcInput	);
	SAFE_NEWINIT(	m_pCam,		CMcCam		);
	SAFE_NEWINIT(	m_pField,	CMcField	);


	ID3DXMesh *pMesh,*pMesh2;

	// create a box at the center of scene, and place in object to be parent to all other objects

	D3DXCreateBox(m_pd3dDevice,2.0f,2.0f,2.0f,&pMesh,NULL);
	m_pScene=new CObj(pMesh);

	// release the mesh, the object we created holds a reference and will release when finished

	pMesh->Release();

	// create a couple smaller meshes

	D3DXCreateSphere(m_pd3dDevice,20.0f,8,8,&pMesh,NULL);
	D3DXCreateBox(m_pd3dDevice,20.f,20.f,20.f,&pMesh2,NULL);

	// loop through and create four spheres orbiting the first object

	for (int i=0;i<4;i++)
	{
		float ang=i*D3DX_PI*0.5f;
		COrbit *orbit=new COrbit(pMesh,100*i,	 D3DXVECTOR3(50*sinf(ang),50*cosf(ang),0.0f), ang,1.0f-0.2f*i);
								
		m_pScene->AddChild(orbit);

		// and put two cubes orbiting each of them

		orbit->AddChild(new COrbit(pMesh2,30, D3DXVECTOR3(0.0f,1.0f,0.0f),0.0f,2.5f));
		orbit->AddChild(new COrbit(pMesh2,36, D3DXVECTOR3(1.0f,0.0f,0.0f),D3DX_PI,2.0f));
	}

	// release meshes

	pMesh->Release();
	pMesh2->Release();

	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE( m_pD3DXFont	);
	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCam		);
	SAFE_DELETE(	m_pField	);

	SAFE_DELETE(m_pScene);

	return S_OK;
}


HRESULT CMain::Restore()
{
	m_pD3DXFont->OnResetDevice();

	return S_OK;
}


HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();

	return S_OK;
}


HRESULT CMain::FrameMove()
{
	SAFE_FRAMEMOVE(	m_pInput	);
	SAFE_FRAMEMOVE(	m_pCam		);

	if(m_pInput->GetKey(DIK_F1))
		m_bSolid ^= 1;

	if(m_pInput->GetKey(DIK_F2))
	{
		m_nCull = (++m_nCull)%3 +1;
	}

	if(m_pInput->GetKey(DIK_F3))
		m_bTx ^=1;



	if(m_pInput->ButtonDown(0))
	{
		SetCapture( m_hWnd );
		m_bPauseAnimation=TRUE;
	}
		
	if(m_pInput->ButtonUp(0))
	{
		m_bPauseAnimation=FALSE;
		ReleaseCapture();
	}


	if (!m_bPauseAnimation)
		m_pScene->FrameMove(m_fElapsedTime);

	else
	{
		int c;
		c=10;
	}

	return S_OK;
}


HRESULT CMain::Render()
{
	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0xFF006699, 1.0f, 0L);

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	GDEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);

	SAFE_RENDER(	m_pField	);

	Pick();
	
	if (m_pScene)
		m_pScene->Render();

	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILLMODE(m_bSolid+2));
	GDEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL(m_nCull));

	RenderText();

	m_pd3dDevice->EndScene();

	return S_OK;
}


HRESULT CMain::RenderText()
{
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pd3dDevice->SetTexture( 0, 0);

	CHAR szMsg[MAX_PATH];
	RECT rc;
	rc.left   = 2;
	rc.right  = m_d3dsdBackBuffer.Width - 20;
	rc.top = 3;
	rc.bottom = rc.top + 20;

	sprintf(szMsg, "%s %s",m_strDeviceStats, m_strFrameStats );

	m_pD3DXFont->Begin();
	m_pD3DXFont->DrawText( szMsg, -1, &rc, 0, D3DXCOLOR(1,1,0,1) );


	rc.top = 23;
	rc.bottom = rc.top + 20;
	VEC3 vcCamPos = m_pCam->GetCamPos();
	sprintf(szMsg, "Camera Pos: %.f %.f %.f",vcCamPos.x, vcCamPos.y, vcCamPos.z );
	m_pD3DXFont->DrawText( szMsg, -1, &rc, 0, D3DXCOLOR(1,1,0,1) );

	m_pD3DXFont->End();

	return S_OK;
}



void CMain::Pick()
{
    D3DXVECTOR3 vPickRayDir;
    D3DXVECTOR3 vPickRayOrig;

    // Get the pick ray from the mouse position
    if( GetCapture() )
    {
        POINT ptCursor;
        GetCursorPos( &ptCursor );
        ScreenToClient( m_hWnd, &ptCursor );

        // Compute the vector of the pick ray in screen space
        D3DXVECTOR3 v;
		D3DXMATRIX	mtPrj = m_pCam->GetMatrixPrj();
		D3DXMATRIX	mtViwI = m_pCam->GetMatrixViwI();

        v.x =  ( 2.0f * ptCursor.x / m_d3dsdBackBuffer.Width  - 1 ) / mtPrj._11;
        v.y = -( 2.0f * ptCursor.y / m_d3dsdBackBuffer.Height - 1 ) / mtPrj._22;
        v.z =  1.0f;

        // Transform the screen space pick ray into 3D space
        vPickRayDir.x  = v.x * mtViwI._11 + v.y * mtViwI._21 + v.z * mtViwI._31;
        vPickRayDir.y  = v.x * mtViwI._12 + v.y * mtViwI._22 + v.z * mtViwI._32;
        vPickRayDir.z  = v.x * mtViwI._13 + v.y * mtViwI._23 + v.z * mtViwI._33;

		D3DXVec3Normalize(&vPickRayDir,&vPickRayDir);
        vPickRayOrig.x = mtViwI._41;
        vPickRayOrig.y = mtViwI._42;
        vPickRayOrig.z = mtViwI._43;

		// calc origin as intersection with near frustum

		vPickRayOrig+=vPickRayDir*m_pCam->GetNear();

		// iterate through the scne and find closest match
		CObj *hitObj=m_pScene->Pick(&vPickRayOrig,&vPickRayDir,m_pCam->GetFar() - m_pCam->GetNear());
	}
}










LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,LPARAM lParam)
{
	WPARAM	wparHi;
	WPARAM	wparLo;

	wparHi = HIWORD(wParam);
	wparLo = LOWORD(wParam);

	switch( msg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC hDC = GetDC( hWnd );
				CHAR strMsg[MAX_PATH];
				RECT rc;
				wsprintf( strMsg, TEXT("Loading... Please wait") );
				GetClientRect( hWnd, &rc );
				DrawText( hDC, strMsg, -1, &rc, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}

		case WM_COMMAND:
		{
			switch(wparLo)
			{
				case ID_MNU_OPEN:
				{
					break;
				}
			}

			break;
		}	// case WM_COMMAND:
	}

	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}









































