// Implementation of the CObj class.
// http://www.mvps.org/directx/articles/rayproj.htm
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CObj::CObj(ID3DXMesh *pMesh)
{
	// clear object pointers
	m_pChild=NULL;
	m_pSibling=NULL;
	m_pParent=NULL;

	// clear hit flag
	m_bHit=FALSE;

	// store mesh pointer
	m_pMesh=pMesh;
	if (pMesh)
		pMesh->AddRef();

	// set world matrix to identity
	D3DXMatrixIdentity(&m_worldMat);
}

CObj::~CObj()
{
	// release mesh, if we have one
	SAFE_RELEASE(m_pMesh);

	// delete children and siblings, if present
	SAFE_DELETE(m_pChild);
	SAFE_DELETE(m_pSibling);
}

void CObj::AddChild(CObj *pObj)
{
	// let child know who it's parent is
	pObj->m_pParent=this;

	// do we already have any children?
	if (m_pChild)
	{

		// yes, give it to first child to add as sibling
		m_pChild->AddSibling(pObj);

		// return to caller
		return;
	}

	// no, add this as our first
	m_pChild=pObj;
}

void CObj::AddSibling(CObj *pObj)
{
	// do we have any siblings yet?
	if (m_pSibling) {

		// yes, let them deal with it
		m_pSibling->AddSibling(pObj);

		// return to caller
		return;
	}

	// no, ad this as our first
	m_pSibling=pObj;
}

CObj *CObj::Pick(D3DXVECTOR3 *pvNear, D3DXVECTOR3 *pvDir, float maxDist, CObj *pObj)
{
	// clear the hit flag
	m_bHit=FALSE;

	// do we have a mesh?
	if (m_pMesh) {

		// yes, convert ray to model space
		D3DXVECTOR3 vNear,vDir;
		D3DXMATRIX invMat;
		D3DXMatrixInverse(&invMat,NULL,&m_combinedMat);
		D3DXVec3TransformCoord(&vNear,pvNear,&invMat);
		D3DXVec3TransformNormal(&vDir,pvDir,&invMat);

		// test for intersection
		BOOL bHit;
		DWORD dwIndex;
		float u,v;
		float dist;
		D3DXIntersect(m_pMesh,&vNear,&vDir,&bHit,&dwIndex,&u,&v,&dist,NULL,NULL);

		// is there an intersection?
		if (bHit) {

			// yes, is it beyond the far plane?
			if (dist<maxDist) {

				// no, have we previously found a hit?
				if (pObj) {

					// yes, but is this one closer?
					if (pObj->m_fHitDist>dist) {

						// yes, clear hit flag of object with previously detected intersection
						pObj->m_bHit=FALSE;

						// set our hit flag
						m_bHit=TRUE;

						// store distance to the hit
						m_fHitDist=dist;

						// set hit object pointer to point to this object
						pObj=this;
					}

				// no, this is the first hit
				} else {

					// set the hit flag
					m_bHit=TRUE;

					// save distance to intersection
					m_fHitDist=dist;

					// set hit object pointer to point to this object
					pObj=this;
				}
			}
		}
	}

	// perform pick operation on children and siblings
	if (m_pChild)
		pObj=m_pChild->Pick(pvNear,pvDir,maxDist,pObj);
	if (m_pSibling)
		pObj=m_pSibling->Pick(pvNear,pvDir,maxDist,pObj);

	// return hit object pointer to caller
	return pObj;
}

void CObj::Render(D3DXMATRIX *pMat)
{
	D3DXMATRIX idMat;

	// start with identity matrix if no matrix passed (true for root object in scene)
	if (!pMat)
	{
		D3DXMatrixIdentity(&idMat);
		pMat=&idMat;
	}

	// calculate composite world matrix and save for later pick operations
	D3DXMatrixMultiply(&m_combinedMat,&m_worldMat,pMat);

	GDEVICE->SetTexture(0, 0);

	// Setup a material
	D3DMATERIAL9 mtrl;
	D3DUtil_InitMaterial( mtrl, 1.0f, 0.0f, 0.0f );
	GDEVICE->SetMaterial( &mtrl );

	// Set up the textures
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	GDEVICE->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	GDEVICE->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );

	// Set miscellaneous render states
	GDEVICE->SetRenderState( D3DRS_DITHERENABLE,   FALSE );
	GDEVICE->SetRenderState( D3DRS_SPECULARENABLE, FALSE );
	GDEVICE->SetRenderState( D3DRS_ZENABLE,        TRUE );
	GDEVICE->SetRenderState( D3DRS_AMBIENT,        0x000F0F0F );

	// Set up lighting states
	D3DLIGHT9 light;
	D3DUtil_InitLight( light, D3DLIGHT_DIRECTIONAL, -1.0f, -1.0f, 2.0f );
	GDEVICE->SetLight( 0, &light );
	GDEVICE->LightEnable( 0, TRUE );
	GDEVICE->SetRenderState( D3DRS_LIGHTING, TRUE );

	// is there a mesh?
	if (m_pMesh)
	{

		// if we were hit in last check, render as yellow wire frame
		if (m_bHit)
		{
			GDEVICE->SetRenderState(D3DRS_FILLMODE,D3DFILL_WIREFRAME);
			D3DMATERIAL9 mtrl;
			D3DUtil_InitMaterial(mtrl,1.0f,1.0f,0.0f);
			GDEVICE->SetMaterial( &mtrl );
		    GDEVICE->SetRenderState(D3DRS_AMBIENT,0x007F7F0F);
		}

		// yes, set the world transformation
		GDEVICE->SetTransform(D3DTS_WORLD,&m_combinedMat);

		// render the mesh
		m_pMesh->DrawSubset(0);

		// if we were hit, restore to solid fill and red material for subsequent objects
		if (m_bHit)
		{
			GDEVICE->SetRenderState(D3DRS_FILLMODE,D3DFILL_SOLID);
			D3DMATERIAL9 mtrl;
			D3DUtil_InitMaterial(mtrl,1.0f,0.0f,0.0f);
			GDEVICE->SetMaterial( &mtrl );
		    GDEVICE->SetRenderState(D3DRS_AMBIENT,0x000F0F0F);
		}
	}

	// are there children?
	if (m_pChild)

		// yes, render them, with our transformation as starting point
		m_pChild->Render(&m_combinedMat);

	// are there siblings?
	if (m_pSibling)

		// yes, render them, using parent transform passed to us
		m_pSibling->Render(pMat);


	D3DXMATRIX w;
	D3DXMatrixIdentity(&w);
	GDEVICE->SetTransform(D3DTS_WORLD, &w);
}

void CObj::FrameMove(float fElapsed)
{
	// base class does not implement any motion
	// call children and siblings in case they do
	if (m_pChild)
		m_pChild->FrameMove(fElapsed);
	if (m_pSibling)
		m_pSibling->FrameMove(fElapsed);
}
