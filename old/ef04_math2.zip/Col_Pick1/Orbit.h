// Orbit.h: interface for the COrbit class.
// http://www.mvps.org/directx/articles/rayproj.htm
////////////////////////////////////////////////////////////////////////////////

#ifndef _ORBIT_H_
#define _ORBIT_H_

class COrbit : public CObj  
{
public:
	void FrameMove(float fElapsed);
	COrbit(ID3DXMesh *pMesh,float fDist,D3DXVECTOR3 vAxis,float fRot,float fVel);
	virtual ~COrbit();
	float m_fDist;
	float m_fRot;
	float m_fVel;
	D3DXVECTOR3 m_vAxis;
};

#endif