// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pD3DXFont		= NULL;
	m_pInput		= NULL;
	m_pCam			= NULL;

	m_pColl			= NULL;

	m_bSolid		= TRUE;
	m_nCull			= 1;
	m_bTx			= 1;
}


HRESULT CMain::Init()
{
	LOGFONT hFont =
	{
		14, 0, 0, 0, FW_BOLD, 0, 0, 0
		,	ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS
		,	ANTIALIASED_QUALITY, FF_DONTCARE, "����ü"
	};

	if( FAILED( D3DXCreateFontIndirect(GDEVICE, &hFont, &m_pD3DXFont) ) )
		return -1;

	SAFE_NEWINIT(	m_pInput,	CMcInput	);
	SAFE_NEWINIT(	m_pCam,		CMcCam		);

	SAFE_NEWINIT(	m_pColl,	CMcClld		);



	FLOAT	fMax;

	fMax = 50000;

	m_pXYZ[ 0] = VtxD(-fMax,     0,     0, 0xFF990000);
	m_pXYZ[ 1] = VtxD(    0,     0,     0, 0xFF990000);
	m_pXYZ[ 2] = VtxD(    0,     0,     0, 0xFFFF3333);
	m_pXYZ[ 3] = VtxD( fMax,     0,     0, 0xFFFF3333);
	
	m_pXYZ[ 4] = VtxD(    0, -fMax,     0, 0xFF009900);
	m_pXYZ[ 5] = VtxD(    0,     0,     0, 0xFF009900);
	m_pXYZ[ 6] = VtxD(    0,     0,     0, 0xFF33FF33);
	m_pXYZ[ 7] = VtxD(    0,  fMax,     0, 0xFF33FF33);
	
	m_pXYZ[ 8] = VtxD(    0,     0, -fMax, 0xFF000099);
	m_pXYZ[ 9] = VtxD(    0,     0,     0, 0xFF000099);
	m_pXYZ[10] = VtxD(    0,     0,     0, 0xFF3333FF);
	m_pXYZ[11] = VtxD(    0,     0,  fMax, 0xFF3333FF);

	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE( m_pD3DXFont	);
	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCam		);

	SAFE_DELETE(	m_pColl	);

	return S_OK;
}


HRESULT CMain::Restore()
{
	m_pD3DXFont->OnResetDevice();

	return S_OK;
}


HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();

	return S_OK;
}


HRESULT CMain::FrameMove()
{
	SAFE_FRAMEMOVE(	m_pInput	);
	SAFE_FRAMEMOVE(	m_pCam		);

	SAFE_FRAMEMOVE(	m_pColl	);


	if(m_pInput->GetKey(DIK_F1))
		m_bSolid ^= 1;

	if(m_pInput->GetKey(DIK_F2))
	{
		m_nCull = (++m_nCull)%3 +1;
	}

	if(m_pInput->GetKey(DIK_F3))
		m_bTx ^=1;

	return S_OK;
}


HRESULT CMain::Render()
{
	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0xFF006699, 1.0f, 0L);

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;


	GDEVICE->SetTexture(0, 0);
	GDEVICE->SetFVF(VtxD::FVF);
	GDEVICE->DrawPrimitiveUP(D3DPT_LINELIST, 6, m_pXYZ, sizeof(VtxD));

	SAFE_RENDER(	m_pColl	);

	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	GDEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);

	RenderText();

	m_pd3dDevice->EndScene();

	return S_OK;
}


HRESULT CMain::RenderText()
{
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pd3dDevice->SetTexture( 0, 0);

	CHAR szMsg[MAX_PATH];
	RECT rc;
	rc.left   = 2;
	rc.right  = m_d3dsdBackBuffer.Width - 20;
	rc.top = 3;
	rc.bottom = rc.top + 20;

	sprintf(szMsg, "%s %s",m_strDeviceStats, m_strFrameStats );

	m_pD3DXFont->Begin();
	m_pD3DXFont->DrawText( szMsg, -1, &rc, 0, D3DXCOLOR(1,1,0,1) );


	rc.top += 43;
	rc.bottom = rc.top + 20;
	rc.left   = 20;
	rc.right  = m_d3dsdBackBuffer.Width - 20;

	sprintf(szMsg, "Collision Line to Sphere. Press Left,Right, Up, Down Key");
	m_pD3DXFont->DrawText( szMsg, -1, &rc, 0, D3DXCOLOR(1,1,1,1) );

	m_pD3DXFont->End();

	return S_OK;
}







LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,LPARAM lParam)
{
	WPARAM	wparHi;
	WPARAM	wparLo;

	wparHi = HIWORD(wParam);
	wparLo = LOWORD(wParam);

	switch( msg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC hDC = GetDC( hWnd );
				CHAR strMsg[MAX_PATH];
				RECT rc;
				wsprintf( strMsg, TEXT("Loading... Please wait") );
				GetClientRect( hWnd, &rc );
				DrawText( hDC, strMsg, -1, &rc, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}

		case WM_COMMAND:
		{
			switch(wparLo)
			{
				case ID_MNU_OPEN:
				{
					break;
				}
			}

			break;
		}	// case WM_COMMAND:
	}

	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}