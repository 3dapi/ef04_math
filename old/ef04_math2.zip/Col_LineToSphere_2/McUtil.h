#ifndef _MCUTIL_H_
#define _MCUTIL_H_


#define SAFE_NEWINIT(p, CLASSTYPE)												\
{																				\
	if(NULL == (p))																\
	{																			\
		p = new CLASSTYPE;														\
																				\
		if(!(p))																\
		{																		\
			return -1;															\
		}																		\
																				\
		if(FAILED((p)->Init()))													\
		{																		\
			delete p;															\
			p = NULL;															\
			return -1;															\
		}																		\
	}																			\
}

	
#define SAFE_RESTORE(p)															\
{																				\
	if(p)																		\
	{																			\
		if(FAILED((p)->Restore()))												\
			return -1;															\
	}																			\
}



#define SAFE_FRAMEMOVE(p)														\
{																				\
	if(p)																		\
	{																			\
		if(FAILED(	(p)->FrameMove()))											\
			return -1;															\
	}																			\
}

#define SAFE_DESTROY(p)		{	if(p)	(p)->Destroy();			}
#define SAFE_INVALIDATE(p)	{	if(p)	(p)->Invalidate();		}
#define SAFE_RENDER(p)		{	if(p)	(p)->Render();			}


#define		SAFE_FREE(p)		{ if(p) { free(p);		(p)=NULL; } }

// Access variable-argument lists �̿��� MessageBox ��Ÿ ��¹�
// Error MessageBox����
void McUtil_ErrMsgBox(TCHAR *format,...);

//������ Ÿ��Ʋ ���� ����
void McUtil_SetWindowTitle(TCHAR *format,...);


INT McUtil_TextureLoad(TCHAR * sFile, PDTX & pTx
						, DWORD color=0xFF000000
						, D3DXIMAGE_INFO *pSrcInfo=NULL
						, DWORD Filter   = (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
						, DWORD MipFilter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
						, D3DFORMAT d3dFormat = D3DFMT_UNKNOWN);


void	McUtil_VBCreate(PDVB& pVB, int nSize, DWORD fvf, void* pVtx=NULL, D3DPOOL usage=D3DPOOL_MANAGED);
void	McUtil_VBLock(PDVB& pVB, int nSize, void* pVtx);
void	McUtil_IBCreate(PDIB& pIB, int nSize, void* pIdx=NULL, D3DFORMAT fmt=D3DFMT_INDEX16, D3DPOOL usage= D3DPOOL_MANAGED);
void	McUtil_IBLock(PDIB& pIB, int nSize, void* pIdx);
void	McUtil_ReadLineQuot(TCHAR *strOut, TCHAR *strIn, INT iC='\"');

#endif _MCUTIL_H_