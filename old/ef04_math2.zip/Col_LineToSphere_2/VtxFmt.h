#ifndef _VTXFMT_H_
#define _VTXFMT_H_


struct VtxD
{
	VEC3	p;
	DWORD	d;
	
	VtxD() : p(0,0,0),d(0xFFFFFFFF){}
	VtxD(FLOAT X,FLOAT Y,FLOAT Z,DWORD D=0xFFFFFFFF) : p(X,Y,Z),d(D){}
	enum	{FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE),};
};

struct VtxIdx
{
	union	{	struct	{	WORD a;	WORD b;	WORD c;	};	WORD m[3];	};

	VtxIdx()							{	a = 0;	  b = 1;		 c = 2;	}
	VtxIdx(WORD A, WORD B, WORD C)		{	a = A;    b = B;		 c = C;	}
	VtxIdx(WORD* R)						{	a = R[0]; b = R[1];	 c = R[2];	}
	operator WORD* ()					{		return (WORD *) &a;			}
	operator CONST WORD* () const		{		return (CONST WORD *) &a;	}
};

#endif