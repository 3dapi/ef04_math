// Interface for the CMcBresenham class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCCLLID_H_
#define _MCCLLID_H_




struct LcLine																	// ������ ������
{
	union	{	struct	{	D3DXVECTOR3 x0;	D3DXVECTOR3 t;	};	FLOAT m[6];	};				// Start Pointer, Tranverse Vector

	LcLine(){}
	LcLine(const FLOAT*_m)	{	if(!_m){m[0]=m[1]=m[2]=m[3]=m[4]=m[5]=0;}else{m[0]=_m[0];m[1]=_m[1];m[2]=_m[2];m[3]=_m[3];m[4]=_m[4];m[5]=_m[5];}}
	LcLine(LcLine& _rh)		{	x0 = _rh.x0; t = _rh.t;	}
	LcLine(FLOAT a,FLOAT b,FLOAT c,FLOAT d,FLOAT e,FLOAT f)	{	m[0]=a;m[1]=b;m[2]=c;m[3]=d;m[4]=e;m[5]=f;}

	LcLine(const D3DXVECTOR3& X0, const D3DXVECTOR3& T)
	{
		x0 = X0;
		t  = T;
	}

	// casting
	operator FLOAT*()						{	return (FLOAT *) &x0.x;			}
	operator const FLOAT*() const			{	return (const FLOAT *) &x0.x;	}

	// unary operators
	LcLine operator+() const				{	return *this;												}
	LcLine operator-() const				{	return LcLine(-x0.x, -x0.y, -x0.z, -t.x, -t.y, -t.z);		}

	BOOL operator==(const LcLine& v) const	{	return x0.x == v.x0.x && x0.y == v.x0.y && x0.z == v.x0.z && t.x == v.t.x && t.y == v.t.y && t.z == v.t.z;	}
	BOOL operator!=(const LcLine& v) const	{	return x0.x != v.x0.x || x0.y != v.x0.y || x0.z != v.x0.z || t.x != v.t.x || t.y != v.t.y || t.z != v.t.z;	}
};







class CMcClld
{
protected:
	VtxD		m_pLine[2];

	BOOL		m_bColl;
	D3DXVECTOR3 m_vcPick;

	FLOAT		m_fR;
	D3DXVECTOR3 m_vcSphere;
	LPD3DXMESH	m_pMsh;

public:
	CMcClld();
	~CMcClld();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif