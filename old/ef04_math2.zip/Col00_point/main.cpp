
#pragma comment(lib, "d3dx9.lib")

#include <stdio.h>
#include <d3dx9.h>

int CollisionPointToPoint(const D3DXVECTOR3* V1
						, const D3DXVECTOR3* V2
						, float fEpsilon=0.0001f)
{
	int hr=-1;

	if( fabsf(V2->x - V1->x) <fEpsilon &&
		fabsf(V2->y - V1->y) <fEpsilon &&
		fabsf(V2->z - V1->z) <fEpsilon)
		hr = 0;

	return hr;
}

int CollisionSphereToSphere(const D3DXVECTOR3* SphereCenter1
							, float sphereRadius1
							, const D3DXVECTOR3* SphereCenter2
							, float sphereRadius2
							)
{
	int hr=-1;

	float Distance;
	D3DXVECTOR3 vcTemp = *SphereCenter1 - *SphereCenter2;

	Distance = D3DXVec3Length(&vcTemp);

	if( (sphereRadius1 + sphereRadius2) <= Distance)
		hr =0;

	return hr;
}


int CollisionSphereToLine(const D3DXVECTOR3* SphereCenter
						, float SphereRadius
						, const D3DXVECTOR3* LineBegin
						, const D3DXVECTOR3* LineDirection
						)
{
	int hr=-1;

	float Hsq;
	D3DXVECTOR3 vcT = *SphereCenter - *LineBegin;
	D3DXVECTOR3 vcL = *LineDirection;

//	float T = D3DXVec3Dot(&vcT, &vcL);
//	T *= T;
//	Hsq =  D3DXVec3LengthSq(&vcT) - T;

	D3DXVECTOR3 vcH;
	D3DXVec3Cross(&vcH, &vcT, &vcL);
	Hsq = D3DXVec3LengthSq(&vcH);

	if( Hsq <= SphereRadius * SphereRadius)
		hr =0;

	return hr;
}


void main()
{
	D3DXVECTOR3 SphereCenter1(10, 0, 10);
	float sphereRadius1= 5;

	D3DXVECTOR3 SphereCenter2(10, 0, -10);
	float sphereRadius2 = 15;

	int hr = CollisionSphereToSphere(&SphereCenter1, sphereRadius1
									, &SphereCenter2, sphereRadius2);


	D3DXVECTOR3 SphereCenter3(20, 0, 0);
	float sphereRadius3 = 10;


	D3DXVECTOR3 LineBegin(10, 0, 10);
	D3DXVECTOR3 LineDirecton(10,0,0);

	D3DXVec3Normalize(&LineDirecton, &LineDirecton);
	CollisionSphereToLine(&SphereCenter3, sphereRadius3, &LineBegin, &LineDirecton);

	printf("%d\n", hr);
}