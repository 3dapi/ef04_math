// Interface for the CMcBresenham class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCCLLID_H_
#define _MCCLLID_H_



struct LnSphere																	// ��
{
	union	{	struct	{	D3DXVECTOR3 p;	FLOAT r;};	FLOAT m[4];	};					// center, Radius

	LnSphere(){}
	LnSphere(const FLOAT*_m)				{	if(!_m){m[0]=m[1]=m[2]=m[3]=0;}else{m[0]=_m[0];m[1]=_m[1];m[2]=_m[2];m[3]=_m[3];}}
	LnSphere(LnSphere& _rh)					{	p = _rh.p; r = _rh.r;	}
	LnSphere( FLOAT X,FLOAT Y,FLOAT Z,FLOAT R){	m[0]=X;m[1]=Y;m[2]=Z;m[3]=R;}

	// casting
	operator FLOAT*()						{	return (FLOAT *) &p.x;				}
	operator const FLOAT*() const			{	return (const FLOAT *) &p.x;		}

	// unary operators
	LnSphere operator+() const				{	return *this;													}
	LnSphere operator-() const				{	return LnSphere(-p.x, -p.y, -p.z, -r);								}

	BOOL operator==(const LnSphere& v) const{	return p.x == v.p.x && p.y == v.p.y && p.z == v.p.z && r == v.r;	}
	BOOL operator!=(const LnSphere& v) const{	return p.x != v.p.x || p.y != v.p.y || p.z != v.p.z || p.y != v.r;	}
};

typedef	std::vector<LnSphere>	lsLnSphere;







class CMcClld
{
protected:
	LnSphere	m_Sphere;

	D3DXVECTOR3		m_Tri[3];
	VtxD		m_VtxT[3];

	INT			m_bColl;
	D3DXVECTOR3 m_vcPick;

	FLOAT		m_fDist;
	FLOAT		m_fRadius;
	D3DXVECTOR3 m_vcSphere;
	LPD3DXMESH	m_pMshSph;
	LPD3DXMESH	m_pMshCol;

public:
	CMcClld();
	~CMcClld();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif