// Implementation of the CMcClld class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"

typedef D3DXPLANE								DPLN;


struct LcLine																	// ������ ������
{
	// Start Pointer, Tranverse Vector
	union	{	struct	{	D3DXVECTOR3 p;	D3DXVECTOR3 t;	};	FLOAT m[6];	};

	LcLine(){}
	LcLine(const FLOAT*_m)		{	if(_m){m[0]=_m[0];m[1]=_m[1];m[2]=_m[2];m[3]=_m[3];m[4]=_m[4];m[5]=_m[5];}else{m[0]=m[1]=m[2]=m[3]=m[4]=m[5]=0;}}
	LcLine(const LcLine& rhs)	{	p = rhs.p; t = rhs.t;	}

	LcLine(FLOAT Px,FLOAT Py,FLOAT Pz,FLOAT Tx,FLOAT Ty,FLOAT Tz)
	{
		p.x = Px;
		p.y = Py;
		p.z = Pz;
		t.x = Tx;
		t.y = Ty;
		t.z = Tz;
	}

	LcLine(const D3DXVECTOR3& P, const D3DXVECTOR3& T)
	{
		p = P;
		t = T;
	}

	// casting
	operator FLOAT*()						{	return (FLOAT *) &p.x;			}
	operator const FLOAT*() const			{	return (const FLOAT *) &p.x;	}

	// unary operators
	LcLine operator+() const				{	return LcLine(p.x, p.y, p.z, t.x, t.y, t.z);		}
	LcLine operator-() const				{	return LcLine(-p.x, -p.y, -p.z, -t.x, -t.y, -t.z);	}

	BOOL operator==(const LcLine& v) const	{	return p.x == v.p.x && p.y == v.p.y && p.z == v.p.z && t.x == v.t.x && t.y == v.t.y && t.z == v.t.z;	}
	BOOL operator!=(const LcLine& v) const	{	return p.x != v.p.x || p.y != v.p.y || p.z != v.p.z || t.x != v.t.x || t.y != v.t.y || t.z != v.t.z;	}
};

// �������� ��� �����
void LcMath_PlaneSet(DPLN* pOut, CONST D3DXVECTOR3* p0, CONST D3DXVECTOR3* p1, CONST D3DXVECTOR3* p2)
{
	D3DXVECTOR3 tp1 = *p1 - *p0;
	D3DXVECTOR3 tp2 = *p2 - *p0;

	D3DXVECTOR3 nT;
	D3DXVec3Cross(&nT, &tp1, &tp2);
	D3DXVec3Normalize(&nT, &nT);

	pOut->a = nT.x;
	pOut->b = nT.y;
	pOut->c = nT.z;
	pOut->d = - D3DXVec3Dot(&nT, p0);
}

FLOAT LcMath_PlaneToPointMinDistance(CONST FLOAT* pPlane/*VECTOR4*/, CONST FLOAT* pPoint /*VECTOR3*/)
{
	// plane ==> n * x + d =0
	return pPlane[0] * pPoint[0] + pPlane[1] * pPoint[1] + pPlane[2] * pPoint[2] + pPlane[3];
}


// ������ ������ �浹��
INT LcMath_PlaneIntersectionWithLine(D3DXVECTOR3* pOut, CONST DPLN* pPn, CONST D3DXVECTOR3* p1, CONST D3DXVECTOR3* vcT)
{
	FLOAT k = D3DXPlaneDotNormal(pPn, vcT);

	if (k == 0)
		return -1;

	k =1.f/k;
	k *= (- D3DXPlaneDotCoord(pPn, p1) );

	if(pOut)
		*pOut = *p1 + k * (*vcT);

	return 1;
}


INT	LcMath_UVFromTri(FLOAT* fU, FLOAT* fV, D3DXVECTOR3* p, D3DXVECTOR3* p0, D3DXVECTOR3* p1, D3DXVECTOR3* p2)
{
	D3DXVECTOR3	vcA = *p1 - *p0;
	D3DXVECTOR3	vcB = *p2 - *p0;
	D3DXVECTOR3	vcP = *p  - *p0;

	FLOAT	fPA = D3DXVec3Dot( &vcA, &vcP);
	FLOAT	fPB = D3DXVec3Dot( &vcB, &vcP);
	FLOAT	fAB = D3DXVec3Dot( &vcA, &vcB);
	FLOAT	fAA = D3DXVec3Dot( &vcA, &vcA);
	FLOAT	fBB = D3DXVec3Dot( &vcB, &vcB);

	FLOAT fD = fAA*fBB - fAB*fAB;

	if(fabsf(fD)<0.000001f)
		return -1;

	*fU = (fPA*fBB - fPB*fAB)/fD;
	*fV = (fPB*fAA - fPA*fAB)/fD;

	return 1;
}


INT	LcMath_LineToSphere(D3DXVECTOR3* pOut,FLOAT* fDst, CONST LcLine* pLine,CONST D3DXVECTOR3* pC,CONST FLOAT fR)
{
	D3DXVECTOR3	vcP;
	D3DXVECTOR3	vcT;
	FLOAT	fT;
	FLOAT	fN;

	vcT = *pC - pLine->p;
	fT = D3DXVec3Dot(&pLine->t, &vcT);

	vcP = pLine->p + fT * pLine->t;

	fN = D3DXVec3LengthSq(&vcT);
	fN -= fT * fT;

	if(fDst)
		*fDst = sqrtf(fN);

	if(pOut)
		*pOut = vcP;

	if(fN < fR*fR)
		return 1;

	return -1;
}



FLOAT LcMath_TriangleBoundSphere(D3DXVECTOR3* pOut,CONST D3DXVECTOR3* pTri)
{
	FLOAT	fR=0.f,	fR2=0.f, fR3=0.f;
	D3DXVECTOR3	q1, q2, q3;

	*pOut =pTri[0];
	*pOut +=pTri[1];
	*pOut +=pTri[2];

	*pOut /= 3.f;

	q1 = *pOut;
	q2 = *pOut;
	q3 = *pOut;

	q1 -= pTri[0];
	q2 -= pTri[1];
	q3 -= pTri[2];

	fR = D3DXVec3Length(&q1);
	fR2 = D3DXVec3Length(&q2);
	fR3 = D3DXVec3Length(&q3);

	if(fR2>fR)
		fR= fR2;

	if(fR3>fR)
		fR= fR3;

	// �ݰ��� ����
	return fR;
}



INT LcMath_SphereToTri(D3DXVECTOR3* pOut, FLOAT* fDist
					   , D3DXVECTOR3* pSphereCenter, FLOAT* pSphereRadius
					   , D3DXVECTOR3* pTri, D3DXVECTOR3* pTriCenter, FLOAT* pTriRadius, D3DXVECTOR3* pTriNormal)
{
	D3DXVECTOR3	vTbndR;
	FLOAT	fTbndR;

	// 1. �ﰢ���� �浹 �ٿ�尡 �ִٸ�..
	if(NULL == pTriCenter)
	{
		fTbndR = LcMath_TriangleBoundSphere(&vTbndR, pTri);
	}
	else
	{
		vTbndR	= *pTriCenter;
		fTbndR	= *pTriRadius;
	}

	D3DXVECTOR3	vcR = vTbndR - *pSphereCenter;
	FLOAT	fRadiusA = D3DXVec3LengthSq( &vcR);


	FLOAT fRadius12 = *pSphereRadius + fTbndR;

	fRadius12 = fRadius12 * fRadius12;

	if(fRadius12 < fRadiusA)
	{
		return -1;
	}


	// 1. �ﰢ�� ����� ��鿡�� ���� �߽ɱ����� �ִܰŸ��� ����� ������ �Ÿ��� ���Ѵ�.
	// �ִܰŸ��� ���� �ݰ溸�� ũ�� �浹�� ����.
	DPLN plane;
	LcMath_PlaneSet(&plane, &pTri[0], &pTri[1], &pTri[2]);

	*fDist = LcMath_PlaneToPointMinDistance((float*)&plane, (FLOAT*)pSphereCenter);

	if( fRadiusA < (*fDist) * (*fDist))
		return -1;

	FLOAT k = D3DXVec3Dot( (D3DXVECTOR3*)&plane, &vcR);

	*pOut = *pSphereCenter + k *  *((D3DXVECTOR3*)&plane);






	FLOAT fU, fV;

	if(FAILED(LcMath_UVFromTri(&fU, &fV, pOut, &pTri[0], &pTri[1], &pTri[2])))
		return -1;

	// 2. �ռ� ���� ������ �ﰢ�� ���ο� �ִٸ� ������ �浹.
	if(fU>=-0.0001f && fU<=1.0001f && fV>=-0.0001f && fV<=1.0001f && (fU+fV)<1.0001f)
		return 1;

	// 3. �ﰢ���� �� ���� �ϳ��� �� �ȿ� �ִ°� �˻�.
	for(int i=0; i<3; ++i)
	{
		D3DXVECTOR3	vcTc = pTri[i] - *pSphereCenter;
		FLOAT	fTr	= D3DXVec3LengthSq( &vcTc);

		if( fTr< (*pSphereRadius) * (*pSphereRadius))
			return 1;
	}


	// 4. �������� �ﰢ���� ���� ��ġ�� ����
	// �ռ� ���� ������ �ﰢ�� �ܺο� �����Ѵٸ� �ﰢ���� ����� �������� ���� �浹�� ���Ѵ�.

	for(i=0; i<3; ++i)
	{
		D3DXVECTOR3 vcTstOut;
		FLOAT fTstDst;
		LcLine pLine;

		INT n0 = (i+0)%3;
		INT n1 = (i+1)%3;

		pLine.p = pTri[n0];
		pLine.t = pTri[n1] - pTri[n0];

		D3DXVec3Normalize(&pLine.t, &pLine.t);

		// ���� �浹�� ������ ���ϰ�...
		if(SUCCEEDED(LcMath_LineToSphere(&vcTstOut, &fTstDst, &pLine, pSphereCenter, *pSphereRadius)))
		{
			// �� ���� ���� ���� �ȿ� �ִ°� �˻�.

			D3DXVECTOR3 vcTA = pTri[n0] - vcTstOut;
			D3DXVECTOR3 vcTB = pTri[n1] - vcTstOut;

			FLOAT fTst = D3DXVec3Dot(&vcTA, &vcTB);

			//���� �ȿ� �ִٸ� fTst<0�̾�� �Ѵ�.
			if(fTst<0.f)
				return 1;

		}
	}



	return -1;
}




CMcClld::CMcClld()
{
	m_bColl		= 0;

	m_pMshSph	= NULL;
	m_pMshCol	= NULL;
}

CMcClld::~CMcClld()
{
	Destroy();
}


INT CMcClld::Init()
{
	m_fDist		= 0.f;
	m_fRadius	= 60;
	m_vcSphere	= D3DXVECTOR3(20, 30, 40);
	m_Sphere	= LnSphere(m_vcSphere.x, m_vcSphere.y, m_vcSphere.z, m_fRadius);

	D3DXCreateSphere(m_pDev, m_fRadius, 25, 25, &m_pMshSph, 0);
	D3DXCreateSphere(m_pDev, 15, 15, 15, &m_pMshCol, 0);


	m_Tri[0] = D3DXVECTOR3(  -200,  -200,  -200);
	m_Tri[1] = D3DXVECTOR3(   120,   100,   200);
	m_Tri[2] = D3DXVECTOR3(   300,    50,   100);

	m_VtxT[0] = VtxD(  -200,  -200,  -200, 0xFFFF0000);
	m_VtxT[1] = VtxD(   120,   100,   200, 0xFF00FF00);
	m_VtxT[2] = VtxD(   300,    50,   100, 0xFF0000FF);

	return 1;
}


void CMcClld::Destroy()
{
	SAFE_RELEASE(	m_pMshSph	);
	SAFE_RELEASE(	m_pMshCol	);
}


INT	CMcClld::FrameMove()
{
	if(pInput->KeyState(VK_UP))
	{
		m_vcSphere.z += 1;
	}

	if(pInput->KeyState(VK_DOWN))
	{
		m_vcSphere.z -= 1;
	}

	if(pInput->KeyState(VK_HOME))
	{
		m_vcSphere.y += 1;
	}

	if(pInput->KeyState(VK_END))
	{
		m_vcSphere.y -= 1;
	}

	if(pInput->KeyState(VK_LEFT))
	{
		m_vcSphere.x -= 1;
	}

	if(pInput->KeyState(VK_RIGHT))
	{
		m_vcSphere.x += 1;
	}

	m_Sphere.p = m_vcSphere;

	D3DXVECTOR3	vTbndR;
	FLOAT	fTbndR;

	// 1. �ﰢ���� �浹 �ٿ�尡 �ִٸ�..
	fTbndR = LcMath_TriangleBoundSphere(&vTbndR, m_Tri);

//	for(int i=0; i<40000; ++i)
	{
		m_bColl = LcMath_SphereToTri(&m_vcPick, &m_fDist, &m_Sphere.p, &m_Sphere.r, m_Tri, &vTbndR, &fTbndR, NULL);
//		m_bColl = LcMath_SphereToTri(&m_vcPick, &m_fDist, &m_Sphere.p, &m_Sphere.r, m_Tri, NULL, NULL, NULL);
	}

	m_VtxT[0].p = m_Tri[0];
	m_VtxT[1].p = m_Tri[1];
	m_VtxT[2].p = m_Tri[2];


	char sMsg[128];

	sprintf(sMsg, "%f %f %f", m_vcPick.x, m_vcPick.y, m_vcPick.z);

	SetWindowText(GHWND, sMsg);

	return 1;
}

void CMcClld::Render()
{
	D3DLIGHT9		Lgt;
	D3DMATERIAL9	mtl;
	D3DXMATRIX		mtW;

	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pDev->SetRenderState( D3DRS_LIGHTING,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);

	m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE);

	m_pDev->SetTexture(0, 0);
	m_pDev->SetFVF(VtxD::FVF);

	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 1, m_VtxT, sizeof(VtxD));

	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);


	D3DUtil_InitLight( Lgt, D3DLIGHT_DIRECTIONAL, -1.0f, -1.0f, 2.0f );
	m_pDev->SetLight( 0, &Lgt );
	m_pDev->LightEnable( 0, TRUE );
	m_pDev->SetRenderState(D3DRS_LIGHTING, TRUE);
	m_pDev->SetRenderState( D3DRS_AMBIENT, 0x000F0F0F );


	D3DUtil_InitMaterial(mtl,1.0f, 0.0f,0.0f);
	m_pDev->SetMaterial( &mtl );

	D3DXMatrixIdentity(&mtW);

	mtW._41 = m_vcSphere.x;
	mtW._42 = m_vcSphere.y;
	mtW._43 = m_vcSphere.z;

//	m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_CW);
	m_pDev->SetTransform(D3DTS_WORLD,&mtW);
	m_pMshSph->DrawSubset(0);


	D3DUtil_InitMaterial(mtl, 0.0f, .8f, .5f);
	m_pDev->SetMaterial( &mtl );

	D3DXMatrixIdentity(&mtW);

	mtW._41 = m_vcPick.x;
	mtW._42 = m_vcPick.y;
	mtW._43 = m_vcPick.z;

	m_pDev->SetTransform(D3DTS_WORLD,&mtW);

	if(SUCCEEDED(m_bColl))
	{
		m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	}

//	m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW);
	m_pMshCol->DrawSubset(0);



	D3DXMatrixIdentity(&mtW);
	m_pDev->SetTransform(D3DTS_WORLD,&mtW);
	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);


}