// Interface for the CMcBresenham class.
// Bresenham Picking
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCBRESENHAM_H_
#define _MCBRESENHAM_H_

template<class T>
struct TsrtG
{
	bool operator()(const T& t1, const T& t2)
	{
		return (t1.fR < t2.fR);
	}
};

struct McRect
{
	VtxD	pVtx[4];

	McRect()
	{
		pVtx[0].d = 0x44FFFF00;
		pVtx[1].d = 0x44FFFF00;
		pVtx[2].d = 0x44FFFF00;
		pVtx[3].d = 0x44FFFF00;
	}
};

typedef vector<McRect >		lsMcRect;
typedef lsMcRect::iterator	itMcRect;


struct McPck
{
	VtxD	pVtx[3];
	FLOAT	fR;
	VEC3	vcP;

	McPck()
	{
		pVtx[0].d = 0xFFFF00FF;
		pVtx[1].d = 0xFFFF00FF;
		pVtx[2].d = 0xFFFF00FF;
	}
};

typedef vector<McPck >		lsPck;


class CMcBrsnPck
{
protected:
	VtxD		m_pXYZ[12];
	VtxD		m_pLine[2];

	FLOAT		m_fW;


	lsMcRect	m_vRc;
	lsPck		m_vVc;


	INT			m_iNx;					// X�� �� ���� ��
	INT			m_iNz;					// Z�� �� ���� ��
	INT			m_iNv;					// ��ü ���� ��
	VtxD*		m_pVc;					// Vertex Buffer

	INT			m_iNfc;					// �ﰢ���� ��
	VtxIdx*		m_pVi;					// Index Buffer
	
public:
	CMcBrsnPck();
	~CMcBrsnPck();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif