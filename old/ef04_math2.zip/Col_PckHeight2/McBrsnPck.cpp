// Implementation of the CMcBrsnPck class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcBrsnPck::CMcBrsnPck()
{
	m_pVc = NULL;
	m_pVi = NULL;
}

CMcBrsnPck::~CMcBrsnPck()
{
	Destroy();
}


INT CMcBrsnPck::Init()
{
	int		x, z;
	FLOAT	fMax;

	fMax = 50000;
	m_fW	= 32;
	m_iNx	= 32+1;
	m_iNz	= 32+1;
	m_iNv	= m_iNx * m_iNz * 3 * 2;


	m_pXYZ[ 0] = VtxD(-fMax,     0,     0, 0xFFFF0000);
	m_pXYZ[ 1] = VtxD(    0,     0,     0, 0xFFFF0000);
	m_pXYZ[ 2] = VtxD(    0,     0,     0, 0xFFFF0000);
	m_pXYZ[ 3] = VtxD( fMax,     0,     0, 0xFFFF0000);
	
	m_pXYZ[ 4] = VtxD(    0, -fMax,     0, 0xFF00FF00);
	m_pXYZ[ 5] = VtxD(    0,     0,     0, 0xFF00FF00);
	m_pXYZ[ 6] = VtxD(    0,     0,     0, 0xFF00FF00);
	m_pXYZ[ 7] = VtxD(    0,  fMax,     0, 0xFF00FF00);
	
	m_pXYZ[ 8] = VtxD(    0,     0, -fMax, 0xFF0000FF);
	m_pXYZ[ 9] = VtxD(    0,     0,     0, 0xFF0000FF);
	m_pXYZ[10] = VtxD(    0,     0,     0, 0xFF0000FF);
	m_pXYZ[11] = VtxD(    0,     0,  fMax, 0xFF0000FF);


	m_pLine[0].p = VEC3(  600, 0, -20);
	m_pLine[1].p = VEC3(  -10, 0,  20);

	m_pLine[0].p = VEC3(  -10, 0, -10);
	m_pLine[1].p = VEC3(  300, 0, 280);



	m_pVc = new VtxD[m_iNv];

	// Fill Vertex buffer
	for(z=0; z<m_iNz; ++z)
	{
		for(x=0; x<m_iNx; ++x)
		{
			int idx = z * m_iNx + x;
			FLOAT fH = (x-m_iNx/2)*(x-m_iNx/2) + (z-m_iNx/2) * (z-m_iNx/2);
			
			fH *= 0.02f;
			fH = 300.f * exp(-fH);
//			fH	= rand()%128;

			m_pVc[idx] = VtxD( x * m_fW
							, fH
							, z * m_fW
							, 0xFF0088DD);
		}
	}



	m_iNfc = (m_iNx-1) * (m_iNz-1) * 2;				// �ﰢ���� ��

	m_pVi = new VtxIdx[m_iNfc];

	// Fill Index buffer
	int k=0;
	for(z=0; z<m_iNz-1; ++z)
	{
		for(x=0; x<m_iNx-1; ++x)
		{
			int idx0 = (z+0) * m_iNx + x;

			m_pVi[k] = VtxIdx(idx0, idx0+m_iNx, idx0+1);
			++k;

			int idx1 = (z+1) * m_iNx + x+1;
			m_pVi[k] = VtxIdx(idx1, idx1-m_iNx, idx1-1);
			++k;
		}
	}

	return 1;
}


void CMcBrsnPck::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pVc	);
	SAFE_DELETE_ARRAY(	m_pVi	);
}


INT	CMcBrsnPck::FrameMove()
{
	VEC3 vcMouse = GCAM->GetCamPos();
	m_pLine[0].p =vcMouse;
	m_pLine[0].p.y =0;

	VEC3 vcPickRayDir = GCAM->Get3DDir(NULL);
	m_pLine[1].p = vcMouse + vcPickRayDir*50000;
	m_pLine[1].p.y =0;

	
	m_vRc.clear();

	VEC3	vcD = m_pLine[1].p- m_pLine[0].p;

	FLOAT	fA;
	FLOAT	fB;
	
	if(0.f == vcD.x)
		fA = FLT_MAX;
	
	else
		fA= vcD.z/vcD.x;

	fA = fA;
	fB = m_pLine[0].p.z - fA * m_pLine[0].p.x;

	for(int i=0; i<m_iNx; ++i)
	{
		FLOAT	x;
		FLOAT	z;

		
		x = i* m_fW;
		z = fA* i + fB/m_fW;
		z = floorf(z);
		
		if( z>=0 && z<(m_iNx-1) && i<(m_iNx-1))
		{
			McRect	rc;
			rc.pVtx[0].p = m_pVc[(INT(z)+0)* m_iNx + i ].p;
			rc.pVtx[1].p = m_pVc[(INT(z)+1)* m_iNx + i ].p;
			rc.pVtx[2].p = m_pVc[(INT(z)+0)* m_iNx + i + 1].p;
			rc.pVtx[3].p = m_pVc[(INT(z)+1)* m_iNx + i + 1].p;

			if( fabsf(rc.pVtx[0].p.x - rc.pVtx[3].p.x) <=m_fW &&
				fabsf(rc.pVtx[0].p.z - rc.pVtx[3].p.z) <=m_fW)
				m_vRc.push_back(rc);
		}



		z = i * m_fW;
		x = (m_fW * i - fB)/(fA*m_fW);
		x = floorf(x);

		if( x>=0 && x<(m_iNx-1))
		{
			if(fA>=0)
			{
				McRect	rc;
				rc.pVtx[0].p = m_pVc[(INT(i)+0)* m_iNx + INT(x) ].p;
				rc.pVtx[1].p = m_pVc[(INT(i)+1)* m_iNx + INT(x) ].p;
				rc.pVtx[2].p = m_pVc[(INT(i)+0)* m_iNx + INT(x) + 1].p;
				rc.pVtx[3].p = m_pVc[(INT(i)+1)* m_iNx + INT(x) + 1].p;

				if( fabsf(rc.pVtx[0].p.x - rc.pVtx[3].p.x) <=m_fW &&
					fabsf(rc.pVtx[0].p.z - rc.pVtx[3].p.z) <=m_fW)
					m_vRc.push_back(rc);
			}

			else if(z>0)
			{
				McRect	rc;
				z = (i-1);
				rc.pVtx[0].p = m_pVc[(INT(z)+0)* m_iNx + INT(x) ].p;
				rc.pVtx[1].p = m_pVc[(INT(z)+1)* m_iNx + INT(x) ].p;
				rc.pVtx[2].p = m_pVc[(INT(z)+0)* m_iNx + INT(x) + 1].p;
				rc.pVtx[3].p = m_pVc[(INT(z)+1)* m_iNx + INT(x) + 1].p;

				if( fabsf(rc.pVtx[0].p.x - rc.pVtx[3].p.x) <=m_fW &&
					fabsf(rc.pVtx[0].p.z - rc.pVtx[3].p.z) <=m_fW)
					m_vRc.push_back(rc);
			}
		}
	}


	if(!m_vRc.empty())
	{
		m_vVc.clear();

		INT iSize = m_vRc.size();

		for(int i=0; i<iSize; ++i)
		{
			VEC3	V0, V1, V2;
			FLOAT	U, V, D;
			
			V0 = m_vRc[i].pVtx[0].p;
			V1 = m_vRc[i].pVtx[1].p;
			V2 = m_vRc[i].pVtx[2].p;

			if(	D3DXIntersectTri( &V0, &V1, &V2, &vcMouse, &vcPickRayDir, &U, &V, &D))
			{
				McPck	Pck;

				// Pick Position
				Pck.vcP = V0 + U * (V1-V0) + V * (V2-V0);

				Pck.pVtx[0].p = V0;
				Pck.pVtx[1].p = V1;
				Pck.pVtx[2].p = V2;
				Pck.fR	= D;

				m_vVc.push_back( Pck );
			}

			V0 = m_vRc[i].pVtx[3].p;
			V1 = m_vRc[i].pVtx[2].p;
			V2 = m_vRc[i].pVtx[1].p;

			if(	D3DXIntersectTri( &V0, &V1, &V2, &vcMouse, &vcPickRayDir, &U, &V, &D))
			{
				McPck	Pck;

				// Pick Position
				Pck.vcP = V0 + U * (V1-V0) + V * (V2-V0);

				Pck.pVtx[0].p = V0;
				Pck.pVtx[1].p = V1;
				Pck.pVtx[2].p = V2;
				Pck.fR	= D;

				m_vVc.push_back( Pck );
			}
		}

		if(!m_vVc.empty())
		{
			sort(m_vVc.begin(), m_vVc.end(), TsrtG<McPck >());
		}
	}
	
	return 1;
}

void CMcBrsnPck::Render()
{
	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	GDEVICE->SetRenderState( D3DRS_LIGHTING,  FALSE);
	GDEVICE->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	GDEVICE->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);
	GDEVICE->SetRenderState( D3DRS_ZENABLE, FALSE);
	
	GDEVICE->SetTexture(0, 0);
	GDEVICE->SetFVF(VtxD::FVF);
	GDEVICE->DrawPrimitiveUP(D3DPT_LINELIST, 6, m_pXYZ, sizeof(VtxD));
	GDEVICE->DrawPrimitiveUP(D3DPT_LINELIST, 1, m_pLine, sizeof(VtxD));

	GDEVICE->SetFVF(VtxD::FVF);
	GDEVICE->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, m_iNv, m_iNfc, m_pVi, D3DFMT_INDEX16, m_pVc, sizeof(VtxD));


	VtxD	pVtx[4];
	int iSize = m_vRc.size();

	McUtil_SetWindowTitle("%d", iSize);

	for(int i=0; i<iSize; ++i)
	{
		pVtx[0] = m_vRc[i].pVtx[0];
		pVtx[1] = m_vRc[i].pVtx[1];
		pVtx[2] = m_vRc[i].pVtx[2];
		pVtx[3] = m_vRc[i].pVtx[3];

		
		
		GDEVICE->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, m_vRc[i].pVtx, sizeof(VtxD));
	}

	if(!m_vVc.empty())
	{
		GDEVICE->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 1, m_vVc[0].pVtx, sizeof(VtxD));
	}

	GDEVICE->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID);

	GDEVICE->SetRenderState( D3DRS_ZENABLE, TRUE);
}