// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pD3DXFont		= NULL;
	m_pInput		= NULL;
	m_pCam			= NULL;

	m_pBresen		= NULL;

	m_bSolid		= TRUE;
	m_nCull			= 1;
	m_bTx			= 1;
}


HRESULT CMain::Init()
{
	LOGFONT hFont =
	{
		14, 0, 0, 0, FW_BOLD, 0, 0, 0
		,	ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS
		,	ANTIALIASED_QUALITY, FF_DONTCARE, "����ü"
	};

	if( FAILED( D3DXCreateFontIndirect(GDEVICE, &hFont, &m_pD3DXFont) ) )
		return -1;

	SAFE_NEWINIT(	m_pInput,	CMcInput	);
	SAFE_NEWINIT(	m_pCam,		CMcCam		);

	SAFE_NEWINIT(	m_pBresen,	CMcBrsnPck	);

	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE( m_pD3DXFont	);
	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCam		);

	SAFE_DELETE(	m_pBresen	);

	return S_OK;
}


HRESULT CMain::Restore()
{
	m_pD3DXFont->OnResetDevice();

	return S_OK;
}


HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();

	return S_OK;
}


HRESULT CMain::FrameMove()
{
	SAFE_FRAMEMOVE(	m_pInput	);
	SAFE_FRAMEMOVE(	m_pCam		);

	SAFE_FRAMEMOVE(	m_pBresen	);


	if(m_pInput->GetKey(DIK_F1))
		m_bSolid ^= 1;

	if(m_pInput->GetKey(DIK_F2))
	{
		m_nCull = (++m_nCull)%3 +1;
	}

	if(m_pInput->GetKey(DIK_F3))
		m_bTx ^=1;

	return S_OK;
}


HRESULT CMain::Render()
{
	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0xFF006699, 1.0f, 0L);

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	SAFE_RENDER(	m_pBresen	);

	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	GDEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);

	RenderText();

	m_pd3dDevice->EndScene();

	return S_OK;
}


HRESULT CMain::RenderText()
{
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pd3dDevice->SetTexture( 0, 0);

	CHAR szMsg[MAX_PATH];
	RECT rc;
	rc.left   = 2;
	rc.right  = m_d3dsdBackBuffer.Width - 20;
	rc.top = 3;
	rc.bottom = rc.top + 20;

	sprintf(szMsg, "%s %s",m_strDeviceStats, m_strFrameStats );

	m_pD3DXFont->Begin();
	m_pD3DXFont->DrawText( szMsg, -1, &rc, 0, D3DXCOLOR(1,1,0,1) );


	rc.top += 23;
	rc.bottom = rc.top + 20;
	VEC3 vcCamPos = m_pCam->GetCamPos();
	sprintf(szMsg, "Camera Pos: %.f %.f %.f",vcCamPos.x, vcCamPos.y, vcCamPos.z );
	m_pD3DXFont->DrawText( szMsg, -1, &rc, 0, D3DXCOLOR(1,1,0,1) );

	m_pD3DXFont->End();

	return S_OK;
}







LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,LPARAM lParam)
{
	WPARAM	wparHi;
	WPARAM	wparLo;

	wparHi = HIWORD(wParam);
	wparLo = LOWORD(wParam);

	switch( msg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC hDC = GetDC( hWnd );
				CHAR strMsg[MAX_PATH];
				RECT rc;
				wsprintf( strMsg, TEXT("Loading... Please wait") );
				GetClientRect( hWnd, &rc );
				DrawText( hDC, strMsg, -1, &rc, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}

		case WM_COMMAND:
		{
			switch(wparLo)
			{
				case ID_MNU_OPEN:
				{
					break;
				}
			}

			break;
		}	// case WM_COMMAND:
	}

	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}









































