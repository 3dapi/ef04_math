// Implementation of the CMcLayer class.
//
//////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"


// Construction/Destruction


CMcLayer::CMcLayer()
{
}

CMcLayer::~CMcLayer()
{
	Destroy();
}


INT CMcLayer::Init()
{
	m_pVtx[0] = VtxD( -300, 10, -100, 0xFFFFFFFF);
	m_pVtx[1] = VtxD(    0, 10, 1000, 0xFFFFFFFF);
	m_pVtx[2] = VtxD( 1000, 10, -100, 0xFFFFFFFF);
	m_pVtx[3] = VtxD( 1000, 10, 1000, 0xFFFFFFFF);


	m_pVtxPck[0] = VtxD(  0, 10, 20, 0xFFFFFF00);
	m_pVtxPck[1] = VtxD( 20, 10, 20, 0xFFFFFF00);
	m_pVtxPck[2] = VtxD(  0, 10,  0, 0xFFFFFF00);
	m_pVtxPck[3] = VtxD( 20, 10,  0, 0xFFFFFF00);

	m_pVtxPck[0].p += D3DXVECTOR3(-10000,0,-10000);
	m_pVtxPck[1].p += D3DXVECTOR3(-10000,0,-10000);
	m_pVtxPck[2].p += D3DXVECTOR3(-10000,0,-10000);
	m_pVtxPck[3].p += D3DXVECTOR3(-10000,0,-10000);

	return 1;
}


void CMcLayer::Destroy()
{
}


INT CMcLayer::FrameMove()
{
	if(pInput->ButtonDown(0))
	{
		D3DXVECTOR3 pck;

		if(SUCCEEDED(GetPickPos(pck)))
		{
			m_pVtxPck[0].p = pck + D3DXVECTOR3(  0,  0, 20);
			m_pVtxPck[1].p = pck + D3DXVECTOR3( 20,  0, 20);
			m_pVtxPck[2].p = pck + D3DXVECTOR3(  0,  0,  0);
			m_pVtxPck[3].p = pck + D3DXVECTOR3( 20,  0,  0);
		}

	}

	return 1;
}


void CMcLayer::Render()
{
	GDEVICE->SetTexture(0, 0);
	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	GDEVICE->SetRenderState(D3DRS_LIGHTING, FALSE);
	GDEVICE->SetRenderState(D3DRS_FOGENABLE, FALSE);
	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);

	GDEVICE->SetFVF(VtxD::FVF);
	GDEVICE->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, m_pVtx, sizeof(VtxD));


	GDEVICE->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, m_pVtxPck, sizeof(VtxD));
	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
}


INT	CMcLayer::GetPickPos(D3DXVECTOR3& pPck)
{
	D3DXVECTOR3	vcCamPos= GCAM->GetCamPos();
	D3DXVECTOR3	vcRayDir = GCAM->Get3DDir();

	FLOAT	U, V, D;

	// 1 ----- 3
	// | .     |
	// |   .   |
	// |     . |
	// 0 ----- 2

	D3DXVECTOR3	p0;
	D3DXVECTOR3	p1;
	D3DXVECTOR3	p2;

	p0 = m_pVtx[0].p;
	p1 = m_pVtx[1].p;
	p2 = m_pVtx[2].p;

	if(D3DXIntersectTri( &p0, &p1, &p2, &vcCamPos, &vcRayDir, &U, &V, &D))
	{
		pPck = p0 + U * (p1 - p0) + V * (p2 - p0);
		return 1;
	}

	p0 = m_pVtx[3].p;
	p1 = m_pVtx[2].p;
	p2 = m_pVtx[1].p;

	if(D3DXIntersectTri( &p0, &p1, &p2, &vcCamPos, &vcRayDir, &U, &V, &D))
	{
		pPck = p0 + U * (p1 - p0) + V * (p2 - p0);
		return 1;

	}

	return -1;
}