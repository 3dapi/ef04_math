// Interface for the CMcLayer class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _MCLAYER_H_
#define _MCLAYER_H_

class CMcLayer
{
public:
	VtxD	m_pVtx[4];
	VtxD	m_pVtxPck[4];														// Picking Rectangle

public:
	CMcLayer();
	~CMcLayer();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();

	INT		GetPickPos(D3DXVECTOR3& pPck);

};

#endif
