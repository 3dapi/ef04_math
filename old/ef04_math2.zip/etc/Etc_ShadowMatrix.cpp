
#pragma comment(lib, "d3dx9.lib")
#include <windows.h>
#include <stdio.h>
#include <d3dx9math.h>

int main()
{
	INT	i,j;

	printf("\n Parallel Lighting..\n\n");

	D3DXMATRIX mtShd1;
	D3DXMATRIX mtShd2;


	D3DXPLANE	vcPlan(40,52,116,2314);
	D3DXVECTOR4	vcLight(210,230,150,0);

	D3DXMatrixShadow(&mtShd1, &vcLight, &vcPlan);

	printf("Shadow matrix from D3D\n\n");

	for(i=0; i<4; ++i)
	{
		for(j=0; j<4; ++j)
		{
			printf("%12.6f   ",mtShd1.m[i][j]);
		}
		printf("\n");
	}

	printf("\n");
	printf("Shadow matrix from Manual\n\n");

	D3DXVECTOR3 L(vcLight.x, vcLight.y, vcLight.z);
	D3DXVECTOR3 N(vcPlan.a, vcPlan.b, vcPlan.c);
	FLOAT		fLen = D3DXVec3Length(&N);

	D3DXVec3Normalize(&N, &N);
	FLOAT		d = vcPlan.d/fLen;

	FLOAT	k = D3DXVec3Dot(&N, &L);


//	mtShd2 =D3DXMATRIX(
//		k - L.x * N.x,	  - L.x * N.y,	  - L.x * N.z,	- L.x * d,
//		  - L.y * N.x,	k - L.y * N.y,	  - L.y * N.z,	- L.y * d,
//		  - L.z * N.x,	  - L.z * N.y,	k - L.z * N.z,	- L.z * d,
//		          0.f,	          0.f,	          0.f,		    k);
//
//	D3DXMatrixTranspose(&mtShd2, &mtShd2);

	mtShd2 = D3DXMATRIX(
		k - N.x * L.x,	  - N.x * L.y,	  - N.x * L.z,	  0,
		  - N.y * L.x,	k - N.y * L.y,	  - N.y * L.z,	  0,
		  - N.z * L.x,	  - N.z * L.y,	k - N.z * L.z,	  0,
		  -   d * L.x,	  -   d * L.y,	  -   d * L.z,	  k);

	for(i=0; i<4; ++i)
	{
		for(j=0; j<4; ++j)
		{
			printf("%12.6f   ",mtShd2.m[i][j]);
		}
		printf("\n");
	}
	

	printf("\n\n");


	printf("\n Point Lighting..\n\n");

	vcLight.w = 1;

	D3DXMatrixShadow(&mtShd1, &vcLight, &vcPlan);

	
	printf("Shadow matrix from D3D\n\n");

	for(i=0; i<4; ++i)
	{
		for(j=0; j<4; ++j)
		{
			printf("%12.6f   ",mtShd1.m[i][j]);
		}
		printf("\n");
	}

	printf("\n");
	printf("Shadow matrix from Manual\n\n");

	L = D3DXVECTOR3(vcLight.x, vcLight.y, vcLight.z);
	N = D3DXVECTOR3(vcPlan.a, vcPlan.b, vcPlan.c);
	fLen = D3DXVec3Length(&N);
	D3DXVec3Normalize(&N, &N);
	d = vcPlan.d/fLen;

	k = D3DXVec3Dot(&N, &L);

//	mtShd2 = D3DXMATRIX(
//		k + d - L.x * N.x,		      - L.x * N.y,	      - L.x * N.z,		- L.x * d,
//		      - L.y * N.x,		k + d - L.y * N.y,	      - L.y * N.z,		- L.y * d,
//		      - L.z * N.x,		      - L.z * N.y,	k + d - L.z * N.z,		- L.z * d,
//		      -   1 * N.x,		      -   1 * N.y,	      -   1 * N.z,			    k);
//
//	D3DXMatrixTranspose(&mtShd2, &mtShd2);

	mtShd2 = D3DXMATRIX(
		k + d - N.x * L.x,		      - N.x * L.y,	      - N.x * L.z,		- 1 * N.x,
		      - N.y * L.x,		k + d - N.y * L.y,	      - N.y * L.z,		- 1 * N.y,
		      - N.z * L.x,		      - N.z * L.y,	k + d - N.z * L.z,		- 1 * N.z,
		      -   d * L.x,		      -   d * L.y,	      -   d * L.z,			    k);


	for(i=0; i<4; ++i)
	{
		for(j=0; j<4; ++j)
		{
			printf("%12.6f   ",mtShd2.m[i][j]);
		}
		printf("\n");
	}
	

	printf("\n");







	return 1;
}

