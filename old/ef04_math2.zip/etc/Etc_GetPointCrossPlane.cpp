VEC3* GetPointCrossPlane(D3DXVECTOR3*p, const D3DXPLANE& n1,const D3DXPLANE& n2,const D3DXPLANE& n3);
FLOAT GetDeterminant(D3DXMATRIX*);


D3DXVECTOR3* GetPointCrossPlane(D3DXVECTOR3*p, const D3DXPLANE& n1,const D3DXPLANE& n2,const D3DXPLANE& n3)
{
	float	X;
	float	Y;
	float	Z;
	float	D;

	D3DXMATRIX	mtX(	-n1.d,	n1.b,	n1.c,	0,
					-n2.d,	n2.b,	n2.c,	0,
					-n3.d,	n3.b,	n3.c,	0,
					0,		0,		0,		1);

	D3DXMATRIX	mtY(	n1.a,	-n1.d,	n1.c,	0,
					n2.a,	-n2.d,	n2.c,	0,
					n3.a,	-n3.d,	n3.c,	0,
					0,		0,		0,		1);

	D3DXMATRIX	mtZ(	n1.a,	n1.b,	-n1.d,	0,
					n2.a,	n2.b,	-n2.d,	0,
					n3.a,	n3.b,	-n3.d,	0,
					0,		0,		0,		1);

	D3DXMATRIX	mtD(	n1.a,	n1.b,	n1.c,	0,
					n2.a,	n2.b,	n2.c,	0,
					n3.a,	n3.b,	n3.c,	0,
					0,		0,		0,		1);

	D = D3DXMatrixDeterminant(&mtD);
	X = D3DXMatrixDeterminant(&mtX);
	Y = D3DXMatrixDeterminant(&mtY);
	Z = D3DXMatrixDeterminant(&mtZ);

	p->x = X/D;
	p->y = Y/D;
	p->z = Z/D;

	return p;
}


FLOAT GetDeterminant(D3DXMATRIX* mtR)
{
	return mtR->_11 * ( mtR->_22 * mtR->_33 - mtR->_23 * mtR->_32) +
	mtR->_12 * ( mtR->_23 * mtR->_31 - mtR->_21 * mtR->_33) +
	mtR->_13 * ( mtR->_21 * mtR->_32 - mtR->_22 * mtR->_31);
}