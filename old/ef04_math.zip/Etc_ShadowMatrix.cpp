
#pragma comment(lib, "d3dx9.lib")
#include <windows.h>
#include <stdio.h>
#include <d3dx9math.h>



void LcxMatrixShadow(void* pOutMatrix, const void* Light, const void* Plane)
{
	D3DXPLANE	P((FLOAT*)Plane);
	D3DXVECTOR4	L((FLOAT*)Light);

	D3DXMATRIX	mtS;
	FLOAT		D =0;

	// Normalize Plane
	D3DXPlaneNormalize(&P, &P);

	// Dot(Plane, Light)
	D = D3DXVec4Dot((D3DXVECTOR4*)&P, (D3DXVECTOR4*)&L);

	// Setup Output Value
	mtS  = D3DXMATRIX
	(
		D - P.a * L.x,	  - P.a * L.y,	  - P.a * L.z,    - P.a * L.w,
		  - P.b * L.x,	D - P.b * L.y,	  - P.b * L.z,    - P.b * L.w,
		  - P.c * L.x,	  - P.c * L.y,	D - P.c * L.z,    - P.c * L.w,
		  - P.d * L.x,	  - P.d * L.y,	  - P.d * L.z,  D - P.d * L.w
	);

	// Copy Output value
	*((D3DXMATRIX*)pOutMatrix) = mtS;
}


void main()
{
	INT	i,j;

	printf("\n Parallel Lighting..\n\n");

	D3DXMATRIX mtShd1;
	D3DXMATRIX mtShd2;


	D3DXPLANE	P(13,52,86,21470);
	D3DXVECTOR4	L(21,23,10,0);

	D3DXMatrixShadow(&mtShd1, &L, &P);
	LcxMatrixShadow(&mtShd2, &L, &P);

	printf("Shadow matrix from D3D'/'Manual\n");

	for(i=0; i<4; ++i)
	{
		for(j=0; j<4; ++j)
			printf("%12.6f   ",mtShd1.m[i][j]);
		
		printf("\n");

		for(j=0; j<4; ++j)
			printf("%12.6f   ",mtShd2.m[i][j]);

		printf("\n");
	}

	printf("\n");

	printf("Point Lighting..\n");
	printf("Shadow matrix from D3D'/'Manual\n");

	L.w = 1.;

	D3DXMatrixShadow(&mtShd1, &L, &P);
	LcxMatrixShadow(&mtShd2, &L, &P);
	

	for(i=0; i<4; ++i)
	{
		for(j=0; j<4; ++j)
			printf("%12.6f   ",mtShd1.m[i][j]);
		
		printf("\n");

		for(j=0; j<4; ++j)
			printf("%12.6f   ",mtShd2.m[i][j]);

		printf("\n");
	}

	printf("\n");
}

