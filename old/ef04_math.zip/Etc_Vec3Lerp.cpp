
#pragma comment(lib, "d3dx9.lib")
#include <windows.h>
#include <stdio.h>
#include <d3dx9math.h>

int main()
{
	INT	i;

	printf("\n D3DXVec3Lerp..\n\n");
	
	D3DXVECTOR3		p;
	D3DXVECTOR3		p1(100, 200, 300);
	D3DXVECTOR3		p2(200, 300, 400);

	for(i=0; i<10; ++i)
	{
		FLOAT w = i*0.1f;
		D3DXVec3Lerp(&p, &p1, &p2, w);
		printf("w:%.1f	%f	%f	%f\n", w, p.x, p.y, p.z);
	}

	printf("\n\n");

	printf("\n Linear Interpolation ..\n\n");

	for(i=0; i<10; ++i)
	{
		FLOAT w = i*0.1f;
		p = p1 + w * (p2-p1);
		printf("w:%.1f	%f	%f	%f\n", w, p.x, p.y, p.z);
	}

	return 1;
}


