
#pragma comment(lib, "d3dx9.lib")
#include <windows.h>
#include <stdio.h>
#include <d3d9.h>
#include <d3dx9.h>


void main()
{
	D3DXMATRIX		mtQ;
	D3DXMATRIX		mtR;

	FLOAT			fBefore;
	D3DXVECTOR3		vBefore;
	D3DXQUATERNION	qBefore;

	FLOAT			fAfter = 0;
	D3DXVECTOR3		vAfter(0,0,0);
	D3DXQUATERNION	qAfter(0,0,0,1);


	FLOAT	fAngle= 130;

	FLOAT	x = 120;
	FLOAT	y = 31;
	FLOAT	z = 40;

	fBefore = D3DXToRadian(fAngle);
	vBefore	= D3DXVECTOR3(x,y,z);

	D3DXVec3Normalize(&vBefore, &vBefore);
	D3DXQuaternionRotationAxis(&qBefore, &vBefore, fBefore);
	D3DXMatrixRotationQuaternion(&mtQ, &qBefore);

	D3DXMatrixRotationAxis(&mtR, &vBefore, fBefore);

	printf("Rotation Matrix:\n");
	printf("%8.5f %8.5f %8.5f %8.5f\n", mtQ._11, mtQ._12, mtQ._13, mtQ._14);
	printf("%8.5f %8.5f %8.5f %8.5f\n", mtR._11, mtR._12, mtR._13, mtR._14);
	
	printf("%8.5f %8.5f %8.5f %8.5f\n", mtQ._21, mtQ._22, mtQ._23, mtQ._24);
	printf("%8.5f %8.5f %8.5f %8.5f\n", mtR._21, mtR._22, mtR._23, mtR._24);

	printf("%8.5f %8.5f %8.5f %8.5f\n", mtQ._31, mtQ._32, mtQ._33, mtQ._34);
	printf("%8.5f %8.5f %8.5f %8.5f\n", mtR._31, mtR._32, mtR._33, mtR._34);

	printf("%8.5f %8.5f %8.5f %8.5f\n", mtQ._41, mtQ._42, mtQ._43, mtQ._44);
	printf("%8.5f %8.5f %8.5f %8.5f\n", mtR._41, mtR._42, mtR._43, mtR._44);
	printf("\n\n");

	D3DXQuaternionRotationMatrix(&qAfter, &mtQ);
	D3DXQuaternionToAxisAngle(&qAfter, &vAfter, &fAfter);
	D3DXVec3Normalize(&vAfter, &vAfter);

	printf("Quaternion(Before):%8.5f %8.5f %8.5f %8.5f\n", qBefore.x, qBefore.y, qBefore.z, qBefore.w);
	printf("Quaternion(After ):%8.5f %8.5f %8.5f %8.5f\n", qAfter.x,  qAfter.y,  qAfter.z,  qAfter.w);
	printf("\n");

	printf("Axis-angle(Before):%8.5f %8.5f %8.5f %8.5f\n", vBefore.x, vBefore.y, vBefore.z, fBefore);
	printf("Axis-angle(After ):%8.5f %8.5f %8.5f %8.5f\n", vAfter.x,  vAfter.y,  vAfter.z, fAfter);
	printf("\n");


	for(int i=0; i<100; ++i)
	{
		FLOAT	fAngle= FLOAT(rand()%360);

		FLOAT	x = FLOAT( 1+rand()%30);
		FLOAT	y = FLOAT( 1+rand()%30);
		FLOAT	z = FLOAT( 1+rand()%30);

		fBefore = D3DXToRadian(fAngle);
		vBefore	= D3DXVECTOR3(x,y,z);

		D3DXVec3Normalize(&vBefore, &vBefore);
		D3DXQuaternionRotationAxis(&qBefore, &vBefore, fBefore);
		D3DXMatrixRotationQuaternion(&mtQ, &qBefore);


		D3DXQuaternionRotationMatrix(&qAfter, &mtQ);
		D3DXQuaternionToAxisAngle(&qAfter, &vAfter, &fAfter);
		D3DXVec3Normalize(&vAfter, &vAfter);

		printf("Quaternion(Before):%8.5f %8.5f %8.5f %8.5f\n", qBefore.x, qBefore.y, qBefore.z, qBefore.w);
		printf("Quaternion(After ):%8.5f %8.5f %8.5f %8.5f\n", qAfter.x,  qAfter.y,  qAfter.z,  qAfter.w);
		printf("\n");

		printf("Axis-angle(Before):%8.5f %8.5f %8.5f %8.5f\n", vBefore.x, vBefore.y, vBefore.z, fBefore);
		printf("Axis-angle(After ):%8.5f %8.5f %8.5f %8.5f\n", vAfter.x,  vAfter.y,  vAfter.z, fAfter);
		printf("\n");
	}
}