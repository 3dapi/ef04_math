

#pragma comment(lib, "d3dx9.lib")

#include <windows.h>
#include <stdio.h>
#include <d3dx9math.h>


void QuaternionSlerp(D3DXQUATERNION* q, const D3DXQUATERNION* q1, const D3DXQUATERNION* q2, FLOAT t)
{
	FLOAT fTheta;
	D3DXQUATERNION  q3;

	FLOAT fDot = (q1->x * q2->x) + (q1->y * q2->y) + (q1->z * q2->z) + (q1->w * q2->w);

	if (fDot < 0)
	{
		fDot = -fDot;
		q3 = -*(q2);
	}
	else
		q3 = *q2;

	if (fDot < 0.9999f)
	{
		fTheta = acosf(fDot);
		*q = (*q1 * sinf(fTheta*(1-t)) + q3 * sinf(fTheta*t))/sinf(fTheta);
		return;
	}
	
	*q = *q1 * (1-t) + q3 * t;
}

int main()
{
	INT	i;

	printf("D3DXQuaternionSlerp..\n\n");
	
	D3DXQUATERNION		q;
	D3DXQUATERNION		pq1(100, 200, 300, 10.f);
	D3DXQUATERNION		pq2(-200, -300, -400, 20.f);

	D3DXQuaternionNormalize(&pq1, &pq1);
	D3DXQuaternionNormalize(&pq2, &pq2);

	for(i=0; i<=10; ++i)
	{
		FLOAT w = i*0.1f;
		D3DXQuaternionSlerp(&q, &pq1, &pq2, w);
		printf("w:%.1f %12.5f %12.5f %12.5f %12.5f\n", w, q.x, q.y, q.z, q.w);

		//q = pq1 + w * (pq2-pq1);
		QuaternionSlerp(&q, &pq1, &pq2, w);
		printf("w:%.1f %12.5f %12.5f %12.5f %12.5f\n\n", w, q.x, q.y, q.z, q.w);
	}

	return 1;
}





