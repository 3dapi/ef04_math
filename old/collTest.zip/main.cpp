
#pragma comment(lib, "d3dx9.lib")

#include <stdio.h>
#include <d3dx9.h>

INT CollisionPointToPoint(const D3DXVECTOR3* V1
						, const D3DXVECTOR3* V2
						, FLOAT fEpsilon=0.0001f)
{
	INT hr=-1;

	if( fabsf(V2->x - V1->x) <fEpsilon &&
		fabsf(V2->y - V1->y) <fEpsilon &&
		fabsf(V2->z - V1->z) <fEpsilon)
		hr = 0;
	
	return hr;
}


INT CollisionSphereToSphere(const D3DXVECTOR3* SphereCenter1
						  , FLOAT sphereRadius1
						  , const D3DXVECTOR3* SphereCenter2
						  , FLOAT sphereRadius2 )
{
	INT hr=-1;

	FLOAT fDistance;
	D3DXVECTOR3 vcTemp = *SphereCenter1 - *SphereCenter2;
	
	fDistance = D3DXVec3Length(&vcTemp);

	if( fDistance <= (sphereRadius1 + sphereRadius2))
		hr =0;

	return hr;
}


INT CollisionSphereToLine(const D3DXVECTOR3* SphereCenter
						, FLOAT sphereRadius
						, const D3DXVECTOR3* LineBegin
						, const D3DXVECTOR3* LineDirection )
{
	INT hr=-1;

	FLOAT fHsq;
	D3DXVECTOR3 vcT = *SphereCenter - *LineBegin;
	D3DXVECTOR3 vcL = *LineDirection;

//	FLOAT fDot = D3DXVec3Dot(&vcT, &vcL);
//	fDot *= fDot;
//	fHsq =  D3DXVec3LengthSq(&vcT) -fDot;

	D3DXVECTOR3 vcH;
	D3DXVec3Cross(&vcH, &vcT, &vcL);
	fHsq = D3DXVec3LengthSq(&vcH);

	if( fHsq <= sphereRadius * sphereRadius)
		hr =0;

	return hr;
}


INT CollisionSphereToFiniteLine(const D3DXVECTOR3* SphereCenter
						, FLOAT sphereRadius
						, const D3DXVECTOR3* LineBegin
						, const D3DXVECTOR3* LineEnd )
{
	INT hr=-1;

	
	D3DXVECTOR3 vcT = *SphereCenter - *LineBegin;

	D3DXVECTOR3 vcL = *LineBegin - *LineEnd;
	D3DXVec3Normalize(&vcL, &vcL);

	FLOAT fDot = D3DXVec3Dot(&vcT, &vcL);

	D3DXVECTOR3	vcH	= *LineBegin + fDot * vcL;
	
	FLOAT fHsq =  D3DXVec3LengthSq(&vcT) - fDot * fDot;

	if( fHsq <= sphereRadius * sphereRadius)
	{
		D3DXVECTOR3 t0 = vcH - *LineBegin;
		D3DXVECTOR3 t1 = vcH - *LineEnd;

		FLOAT t = D3DXVec3Dot(&t0, &t1);

		if(t <= 0.0)
			hr = 0;
	}

	return hr;
}



INT CollisionPointToLine(const D3DXVECTOR3* V
						 , const D3DXVECTOR3* P1
						 , const D3DXVECTOR3* P2
						 , FLOAT fEpsilon=0.0001f )
{
	INT hr=-1;

	FLOAT fHsq;
	D3DXVECTOR3 vcT = *V - *P1;
	D3DXVECTOR3 vcL = *P2 - *P1;

	D3DXVECTOR3 vcH;
	D3DXVec3Cross(&vcH, &vcT, &vcL);
	fHsq = D3DXVec3LengthSq(&vcH);

	if( fHsq > fEpsilon)
		return hr;

	FLOAT L =	fabsf( P2->x - P1->x) +
				fabsf( P2->y - P1->y) +
				fabsf( P2->z - P1->z);

	FLOAT L1 =	fabsf( V->x - P1->x) +
				fabsf( V->y - P1->y) +
				fabsf( V->z - P1->z);

	FLOAT L2 =	fabsf( V->x - P2->x) +
				fabsf( V->y - P2->y) +
				fabsf( V->z - P2->z);

	if( (L1 + L2)< (L+fEpsilon))
		hr =0;

	return hr;
}


//INT CollisionPointToLine(const D3DXVECTOR3* V
//						 , const D3DXVECTOR3* P1
//						 , const D3DXVECTOR3* P2
//						 , FLOAT fEpsilon=0.0001f )
//{
//	INT hr=-1;
//
//	FLOAT fHsq;
//	D3DXVECTOR3 vcT1 = *V - *P1;
//	D3DXVECTOR3 vcT2 = *V - *P2;
//	D3DXVECTOR3 vcL = *P2 - *P1;
//
//	D3DXVECTOR3 vcH;
//	D3DXVec3Cross(&vcH, &vcT1, &vcL);
//	fHsq = D3DXVec3LengthSq(&vcH);
//
//	if( fHsq > fEpsilon)
//		return hr;
//
//	FLOAT fDot =	D3DXVec3Dot(&vcT1, &vcT2);
//
//	if( fDot<=0.f)
//		hr =0;
//
//	return hr;
//}


INT CollisionPointToPlan(const D3DXVECTOR3* P
						, const D3DXVECTOR3* N
						, FLOAT D
						, FLOAT fEpsilon=0.0001f )
{
	INT hr=-1;

	FLOAT d = D3DXVec3Dot(N, P) - D;

	if(d< fEpsilon)
		hr =0;

	return hr;
}


void main()
{
	D3DXVECTOR3 SphereCenter1(10, 0, 10);
	FLOAT sphereRadius1= 5;
	
	D3DXVECTOR3 SphereCenter2(10, 0, -10);
	FLOAT sphereRadius2 = 15;

	INT hr = CollisionSphereToSphere(&SphereCenter1, sphereRadius1
									, &SphereCenter2, sphereRadius2);


	D3DXVECTOR3 SphereCenter3(20, 0, 0);
	FLOAT sphereRadius3 = 10;


	D3DXVECTOR3 LineBegin(10, 0, 10);
	D3DXVECTOR3 LineDirecton(10,0,0);

	D3DXVec3Normalize(&LineDirecton, &LineDirecton);
	CollisionSphereToLine(&SphereCenter3, sphereRadius3, &LineBegin, &LineDirecton);
	
	printf("%d\n", hr);
}